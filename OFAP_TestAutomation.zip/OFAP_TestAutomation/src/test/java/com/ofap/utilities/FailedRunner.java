package com.ofap.utilities;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

import com.ofap.base.TestBase;

public class FailedRunner extends TestBase
{
	TestNG runner = new TestNG();
	
	List<String> list = new  ArrayList<String>();
	
	//list.add("C:\Users\Biswajit.Pattanaik\OFAP_TestAutomation\test-output\Suite\testng-failed.xml");
	
		//runner.setTestSuites(list);
	
}
