package com.ofap.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class DataBaseManager extends globalLibrary
{
	private static Connection con = null;
	private static Connection conn = null;
	private static Statement statement = null;
	private static ResultSet resultSet = null;
	private static ResultSetMetaData rsmd = null;
	private static SimpleDateFormat sdf = new SimpleDateFormat("m/d/yy");
	
	
	
	globalLibrary gl = new globalLibrary();

	public void setDbConnection() 
	{
		try{
		Class.forName(DataBaseConfig.oracledriver);
		con =	DriverManager.getConnection(DataBaseConfig.oraclelurl, DataBaseConfig.oracleuserName, DataBaseConfig.oraclepassword);
		
		if(!con.isClosed())
			System.out.println("Successfully Connected to Oracle Data Base Server !!!");
		test.log(LogStatus.INFO, "Successfully Connected to Oracle Data Base Server !!!");
		log.debug("Successfully Connected to Oracle Data Base Server !!!");

			
	}catch(Exception e){
		System.err.println("Exception: " + e.getMessage());

		//monitoringMail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject+" - (Script failed with Error, Oracle database used for reports, connection not established)", TestConfig.messageBody, TestConfig.attachmentPath, TestConfig.attachmentName);			
		}
		
		
	}
	
	
	public  void getQueryTable() throws SQLException{
		
		PreparedStatement ps=con.prepareStatement("select source_system,reference_key,payload_file,target_job_id,s1_status,s2_status,s3_status,s4_status,s5_status,s6_status,overall_status,to_char(last_updated_date,'DD-MM-YYYY HH24:mi:ss'),to_char(systimestamp,'DD-MM-YYYY HH24:mi:ss') \r\n" + 
				"from xxtraf.xxtraf_control_details where last_updated_date > sysdate -2/24 and source_system = 'TITAN' order by last_updated_date desc");  
		ResultSet rs=ps.executeQuery();  
		ResultSetMetaData rsmd=rs.getMetaData();  
		
		int columnNo = rsmd.getColumnCount();
		int i=1;
		List<String> values = new ArrayList<String>();
		while(rs.next())
		{
			for(int j=1; j<columnNo; j++)
			{
				values.add(rs.getString(j));
				System.out.println(values);
			}
			//i=i++;
		}
		System.out.println("Total columns: "+rsmd.getColumnCount());  
		System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
		System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));  
		
		test.log(LogStatus.INFO, "Phase the record from DB as per the Query !!!");
		log.debug("Phase the record from DB as per the Query and the Table Name is:  ");

		
	}
		
	public  void getQuery() throws SQLException{
		
		String query="select source_system,reference_key,payload_file,target_job_id,s1_status,s2_status,s3_status,s4_status,s5_status,s6_status,overall_status,to_char(last_updated_date,'DD-MM-YYYY HH24:mi:ss'),to_char(systimestamp,'DD-MM-YYYY HH24:mi:ss') \r\n" + 
				"from xxtraf.xxtraf_control_details where last_updated_date > sysdate -2/24 and source_system = 'TITAN' order by last_updated_date desc";
		Statement St = con.createStatement();
		ResultSet rs = St.executeQuery(query);
		//List<String> values = new ArrayList<String>();
		int i=1;
		while(rs.next())
		{
			
			//System.out.println(values.add(rs.getString(1)));
			String tran = rs.getString(5);
			System.out.println(tran);
			i=i++;
		}
		//return values;
	}
	
	public List<String> getMysqlQuery(String query) throws SQLException
	{
		
		Statement St = conn.createStatement();
		ResultSet rs = St.executeQuery(query);
		
		int i=1;
		List<String> values = new ArrayList<String>();
		while(rs.next())
		{
			values.add(rs.getString(i));
			System.out.println(values);
			i=i++;
		}
		return values;
	}
	
	

	public static Connection getConnection()
	{
		return con;
	}
	
	public static Statement getStatement()
	{
		try
		{
			statement = con.createStatement();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return statement;
	}
	
	
	public void dbClose() throws SQLException
	{
		if (con!=null && con.isClosed())
		{
			con.isClosed();
			System.out.println("Disconnected from Oracle DB");
		}
	}

}
