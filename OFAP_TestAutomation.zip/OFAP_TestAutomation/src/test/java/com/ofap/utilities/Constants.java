package com.ofap.utilities;

public class Constants 
{
	public static String Data_Sheet = "testdata";
}
