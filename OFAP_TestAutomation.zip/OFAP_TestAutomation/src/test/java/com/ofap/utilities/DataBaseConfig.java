package com.ofap.utilities;

public class DataBaseConfig
{
	//public static String server="smtp.gmail.com";
	public static String server="smtp.trafigura.com";
	public static String from = "biswajitp245@gmail.com";
	public static String password = "Selenium@XXXXXX";
	public static String[] to ={"biswajitp245@gmail.com","pbiswajit.ext@deloitte.com","biswajit.pattanaik@trafigura.com"};
	public static String subject = "Extent Project Report";
	
	public static String messageBody ="TestMessage";
	public static String attachmentPath="c:\\screenshot\\2017_10_3_14_49_9.jpg";
	public static String attachmentName="error.jpg";
	
	//ORACLE DATABASE DETAILS-  DEV 
	public static String oracledriver="oracle.jdbc.driver.OracleDriver";
	public static String oracleuserName = "XXTRAF";
	public static String oraclepassword = "TRafigura##123";
	public static String oraclelurl = "jdbc:oracle:thin:@130.61.34.12:1521/ORADBDEV_fra1wd.publicsubnethoj.trafiguravcn.oraclevcn.com";  
	

	
	//SQL DATABASE DETAILS	
	public static String driver="net.sourceforge.jtds.jdbc.Driver"; 
	public static String dbConnectionUrl="jdbc:jtds:sqlserver://192.101.44.22;DatabaseName=monitor_eval"; 
	public static String dbUserName="sa"; 
	public static String dbPassword="$ql$!!1"; 
	
	
	//MYSQL DATABASE DETAILS
	public static String mysqldriver="com.mysql.jdbc.Driver";
	public static String mysqluserName = "root";
	public static String mysqlpassword = "selenium";
	public static String mysqlurl = "jdbc:mysql://localhost:3306/acs";
	
}
