package com.ofap.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.ofap.utilities.ExcelReader;
import com.ofap.utilities.ExtentManager;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestBase 
{
	/* WebDriver
	 * Logs
	 * Properties
	 * Excel- Data Driven
	 * Extent Report
	 * Screenshot and Email Sending
	 * */
	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties OR = new Properties();
	public static Properties cj = new Properties();
	public static FileInputStream fis;
	public static FileOutputStream fisout;
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx");
	//public static ExcelReader exceltitan = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\titan.xlsx");
	//public static ExcelReader excelmurex = new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\murex.xlsx");
	public static WebDriverWait wait;
	public ExtentReports report = ExtentManager.getInstance(); 
	public static ExtentTest test;
	public static String browser;
	
	@BeforeSuite (description = "Loaded all the Browser, [Data, Logs, Reports - Files]")
	public void setUp()
	{
		//BasicConfigurator.configure();
		if (driver == null) 
		{

			try 
			{
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Config.properties");
			} catch (FileNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try 
			{
				config.load(fis);
				log.debug("Config file loaded !!!");
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try 
			{
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\OR.properties");
			} catch (FileNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try 
			{
				OR.load(fis);
				log.debug("OR file loaded !!!");
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try 
			{
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\log4j.properties");
				log.debug("log4j file loaded !!!");
			} catch (FileNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try 
			{
				fis = new FileInputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Journals.properties");
			} catch (FileNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try 
			{
				cj.load(fis);
				log.debug("Journals Property file loaded !!!");
			} catch (IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			if(System.getenv("browser")!=null && !System.getenv("browser").isEmpty())
			{
				browser = System.getenv("browser");
			}
			else
			{
				browser = config.getProperty("browser");
			}
			
			config.setProperty("browser", browser);

			if (config.getProperty("browser").equals("firefox")) {

				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\geckodriver.exe");
				driver = new FirefoxDriver();

			} else if (config.getProperty("browser").equals("chrome")) {

				System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
				driver = new ChromeDriver();
				log.debug("Chrome Launched !!!");
				
			} else if (config.getProperty("browser").equals("ie")) {

				System.setProperty("webdriver.ie.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\IEDriverServer.exe");
				driver = new InternetExplorerDriver();

			}
		}
	}
	
	@AfterSuite(description = "All Browsers Quit!")
	public void tearDown()
	{

		if (driver != null) 
		{
			driver.quit();
		}

		log.debug("**********************  Test Execution Completed !!! ******************************");
		test.log(LogStatus.INFO, "**********************  Test Execution Completed !!! ******************************");
		
	}
	
}

