package com.ofap.testcases.workday;

import java.io.IOException;

import org.testng.annotations.Test;


//JIRA No. : OFAP-1022
//Test Case ID: WD-03
//Test Case Details/scenario :
//Validating WD generated file pickup by Oracle GL on daily basis

public class WD03 
{
	
	
	@Test()
	public void excelTest() throws IOException
	{
		
	}
}
