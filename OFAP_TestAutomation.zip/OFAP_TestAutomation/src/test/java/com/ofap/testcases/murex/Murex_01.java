package com.ofap.testcases.murex;

import java.io.IOException;
import java.text.ParseException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.murex.ReviewJournal_Murex;
import com.ofap.pages.murex.TransactionLine_Murex;
import com.ofap.pages.titan.AccountHeadDetails;
import com.ofap.pages.titan.ReviewJournal;
import com.relevantcodes.extentreports.LogStatus;

public class Murex_01 extends globalLibrary
{
		HomePage hp = new HomePage();
		globalLibrary gl = new globalLibrary();
		ReviewJournal rj = new ReviewJournal();
		AccountHeadDetails acchead = new AccountHeadDetails();
		ReviewJournal_Murex rjm = new ReviewJournal_Murex();
		TransactionLine_Murex tlm = new TransactionLine_Murex();
		
		
		@BeforeTest
		public void before() throws InterruptedException, IOException, ParseException
		{
			
			String testcase01 = excel.getCellData("test_suite", "TestCaseName", 5);
			test.log(LogStatus.INFO, "Name of the Test Case Murex 02   :       " + testcase01);
		  	
			hp.homeIcon(); //Click on Home Icon
			//hp.generalAccounting();  //Click on General Accounting Icon
			hp.generalAccountingJournals();  //Click on Journal Icon
			hp.taskIcon();	//Click on Task Icon
			gl.veriticalScroll();
			gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
		
		}
		
		
		@AfterTest
		public void after() throws InterruptedException, IOException, ParseException
		{
			gl.click("ReviewButtonDone_XPATH");
			test.log(LogStatus.INFO, "Back to the Journal Page   :  By Clicking Review Button     ");
			gl.click("ReviewButtonDone_XPATH");
		}
		
		
		@Test(priority=2)
		public void murex_01() throws InterruptedException, IOException, ParseException
		{

			rjm.transactionSearch_Murex();//After giving input click on Search Button
			rj.reviewJournalEntry(); //Click on [Review Journal Entry] Button
			rj.reviewTransactionEntry();  //Click on [View Transaction] Button
			//tlm.verifyTransactionLine();
			//rj.verifyTransactionHeader(); //Verify Journal Transaction Header Data
			rjm.verifyJournalLineDrCrTotal();
			rj.clickDone();
			rj.viewSupportingReferences(); //Click on Each Icon of Supporting References and Verify Inside the Data
			rj.clickDone();
			//rj.verifyJournalLineDrCrTotal(); //Verify [Debit Total == Credit Total]
			rj.clickDone();
		}
}
