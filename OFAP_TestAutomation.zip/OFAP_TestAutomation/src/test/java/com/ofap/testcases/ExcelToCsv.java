package com.ofap.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.testng.annotations.Test;

import com.ofap.base.TestBase;
import com.ofap.xlsxcsv.AlterCellData;
import com.ofap.xlsxcsv.CreateFolder;
import com.ofap.xlsxcsv.DeleteFolder;
import com.ofap.xlsxcsv.ExportToCSV;
import com.ofap.xlsxcsv.FTPCopyFiles;
import com.ofap.xlsxcsv.FileMove;
import com.ofap.xlsxcsv.RenameFile;
import com.ofap.xlsxcsv.ZipFolder;

public class ExcelToCsv extends TestBase
{
	ExportToCSV export = new ExportToCSV();
	ZipFolder zf = new ZipFolder();
	RenameFile rf = new RenameFile();
	FileMove fm = new FileMove();
	FTPCopyFiles ftp = new FTPCopyFiles();
	DeleteFolder df = new DeleteFolder();
	CreateFolder cf = new CreateFolder();
	AlterCellData acd = new AlterCellData();
	
	@Test(priority=10)
	public void fileProcess() throws IOException
	{
		export.exportToCSVHeader();
		export.exportToCSVLine();
		//Source Directory for ZIP.
		
		
		File directoryToZip = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\");

		List<File> fileList = new ArrayList<File>();
		System.out.println("---Getting references to all files in: " + directoryToZip.getCanonicalPath());
		zf.getAllFiles(directoryToZip, fileList);
		System.out.println("---Creating zip file");
		zf.writeZipFile(directoryToZip, fileList);
		System.out.println("---Done");
		
		rf.rename();
		
		String fileLocationSourceNetwork = "Z:\\inbound\\";
		String fileLocationSourceDrive = System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\";
		String fileLocationDestination = "Z:\\inbound\\";
		int numberOfFilesToCopy = 3;
		System.out.println(fileLocationDestination);
		/**Copy the files from the network**/
		ftp.copyFiles(fileLocationSourceNetwork, fileLocationDestination, numberOfFilesToCopy);
		System.out.println("nn");
		 
		/**Copy the files from the drive**/
		ftp.copyFiles(fileLocationSourceDrive, fileLocationDestination, numberOfFilesToCopy);
		
		df.deleteFolder();
		
		cf.createDirectory();
	}	

}
