package com.ofap.testcases;

import java.io.IOException;
import java.util.Hashtable;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.utilities.TestUtil;
import com.relevantcodes.extentreports.LogStatus;

public class DoLoginTest extends globalLibrary 
{
	/*
	 *Login Functionality, Credential are from Excel Sheet.
	 */
	globalLibrary gl = new globalLibrary();
	
	//@Test(priority=0,dataProviderClass=TestUtil.class,dataProvider="dp")
	//public void doLoginTest(Hashtable<String,String> data) throws InterruptedException
	//{
	@Test(priority=0)
	public void doLoginTest() throws InterruptedException
	{
		
		gl.login();
		Thread.sleep(2000);
//		driver.findElement(By.xpath("//div[@id='otherTileText']")).click();
		//driver.findElement(By.xpath("//button[@id='ssoBtn']")).click();
		gl.isElementPresent("microsoftemail_XPATH");
		gl.waitClick("microsoftemail_XPATH");
		Thread.sleep(2000);
		String userName = excel.getCellData("Login", "username", 2);
		gl.writeText("microsoftemail_XPATH", userName);
		//driver.findElement(By.xpath("//input[@type='email']")).sendKeys("biswajit.pattanaik@trafigura.com");
		gl.click("microsoftNextBtn_XPATH");
		//driver.findElement(By.xpath("//input[@id='idSIButton9']")).click();
		
		/*
		
		gl.login();
		try
		{
		  if(!data.get("runmode").equals("Y"))
			{
				 
				throw new SkipException("Skipping the test case as the Run mode for data set is NO");
			}
			
			System.setProperty("test-output", "false");
			Reporter.log("Inside the Login Page !!!");
			log.debug("Inside the Login Page !!!");
			log.debug("Enter User Name !!!");
			gl.writeText("userID_XPATH",data.get("username"));
			log.debug("Enter User Password !!!");
			gl.writeText("userPwd_XPATH",data.get("password"));
			log.debug("Click on Sign-In button");
			gl.click("signIn_XPATH");
			Reporter.log("Login Successfully Done !!!");
			//Thread.sleep(2000);
			gl.isElementPresent("verifyLogin_XPATH");
			

		}catch (NoSuchElementException e) 
		{
			try {
					TestUtil.captureScreenshot();
				} catch (IOException e1) 
				{
				e1.printStackTrace();
				}
			//Extent Reports
			test.log(LogStatus.FAIL, "Authentication Failed. Due To Login Credential Mismatch:   " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}	
			
			*/

		/*
		 * Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		 * 
		 * Assert.assertTrue(alert.getText().contains(data.get("alerttext")));
		 * alert.accept();
		 * 
		 * 
		 * Thread.sleep(2000);
		 */

		}
	
}
