package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-14
/*Test Case Details/scenario :
"With API server down, Validate the updates are picking up after restore
Pre conditions: Bring down API services down during file pickup schedule and update 
the employee details in Work day. Bring back the services up"
*/

public class WD14 
{

}
