package com.ofap.testcases.workday;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.workday.PersonManagement;
import com.ofap.utilities.TestUtil;

//JIRA No. : OFAP-1022
//Test Case ID: WD-02
//Test Case Details/scenario :
//Validating WD generated employee register pickup by Oracle GL hourly basis

public class WD02 extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	HomePage hp = new HomePage();
	PersonManagement pm = new PersonManagement();
	
	@Test(priority=0,dataProviderClass=TestUtil.class,dataProvider="dp")
	public void doLoginTest(Hashtable<String,String> data) throws InterruptedException, IOException
	{
		gl.login();
		if(!data.get("runmode").equals("Y"))
		{
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		
		Reporter.log("Inside the Login Page !!!");
		log.debug("Inside the Login Page !!!");
		log.debug("Enter User Name !!!");
		gl.writeText("userID_XPATH",data.get("username"));
		log.debug("Enter User Password !!!");
		gl.writeText("userPwd_XPATH",data.get("password"));
		log.debug("Click on Sign-In button");
		gl.click("signIn_XPATH");
		Reporter.log("Login Successfully Done !!!");
		Thread.sleep(2000);
		
		hp.navigator(); //Click on Navigator Icon
		pm.personMgmt();  //Click on Person Management Link  Icon Navigator List
		pm.employeeSearch();  //Click on Employee Link !!!
		pm.employeeDetailsVerifyName(); //Verify Employee First Name and Last Name
	}
}
