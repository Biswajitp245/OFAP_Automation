package com.ofap.testcases.ifx;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.ifx.CurrencyRateManager;
import com.ofap.pages.ifx.SetupMaintenance;
import com.ofap.pages.titan.AccountHeadDetails;
import com.ofap.pages.titan.ReviewJournal;
import com.relevantcodes.extentreports.LogStatus;

public class IFX_01 extends globalLibrary
{
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	SetupMaintenance sm = new SetupMaintenance();
	CurrencyRateManager crm = new CurrencyRateManager();
	
	@BeforeTest
	public void before() throws InterruptedException, IOException, ParseException, SQLException
	{
		String testcase01 = excel.getCellData("test_suite", "TestCaseName", 5);
		test.log(LogStatus.INFO, "Name of the Test Case IFX 01   :       " + testcase01);
	  	
		hp.homeIcon();  // Click on Home Icon
		Thread.sleep(2000);
		hp.setupMaintenance(); //Click on Setup and Maintenance Image or Icon on the Home Page
		sm.dailyRatesLink(); //1. Input value Daily Rates, 2. Click on Search Button, 3. Click on Manage Daily Rates link.
		crm.dailyRatesTab(); //Click on Daily Rates Tab
		
	}
	
	
	@AfterTest
	public void after() throws InterruptedException, IOException, ParseException
	{
		Thread.sleep(2000);
		gl.isElementPresent("SAFResetButton_XPATH");
		gl.click("SAFResetButton_XPATH");
		
	}
	
	
	@Test(priority=2)
	public void ifx_01() throws InterruptedException, IOException, ParseException
	{
		crm.dailyRates(); // Giving Currency Details with Date and Type
		crm.verifyDailyRates(); //Verify Daily Rates from Search Result
	}
}
