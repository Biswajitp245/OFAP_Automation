package com.ofap.testcases.ifx;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import org.testng.annotations.Test;
import com.ofap.base.globalLibrary;
import com.ofap.pages.DataBaseFunctional;
import com.ofap.utilities.DataBaseManager;

public class IFX_DB  extends globalLibrary
{
	DataBaseManager dbm = new DataBaseManager();
	
	
	@Test(priority=2)
	public void iFX_DB () throws InterruptedException, IOException, ParseException, SQLException
	{
		dbm.setDbConnection();
		dbm.getQueryTable();
		
		dbm.getQuery();
		
	}
}
