package com.ofap.testcases.workday;

import java.io.IOException;

import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.workday.PersonManagement;

//JIRA No. : OFAP-1022
//Test Case ID: WD-01
//Test Case Details/scenario :
//"Validating WD generated employee register pickup by Oracle GL at defined Schedules ex: 5:00PM in the evening"

public class WD01 extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	HomePage hp = new HomePage();
	PersonManagement pm = new PersonManagement();
	
	//"Oracle should pickup the file and the below tags should populate with data into Oracle Application.
	//Verify Madatory Fields : First Name, *Last Name, *Email, *Hire Date, *Person Type
	//Verify Other Fields : Legal Employer, Business Unit, User Login, Manager, Location, Cost Center, Entity Code, Termination Date, Act"

	
	@Test(priority=1)
	public void work_Day_01() throws IOException
	{
		hp.navigator(); //Click on Navigator Icon
		pm.personMgmt();  //Click on Person Management Link  Icon Navigator List
		pm.employeeSearch();  //Click on Employee Link !!!
		pm.employeeDetailsVerifyName();
		pm.employeeDetailsVerifyMandatoryData();
	}

}
