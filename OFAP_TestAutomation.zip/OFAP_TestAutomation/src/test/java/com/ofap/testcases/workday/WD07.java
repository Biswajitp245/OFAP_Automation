package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-07
//Test Case Details/scenario :
//Validate workday change in Business unit picked up by Oracle

public class WD07 {

}
