package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-11
//Test Case Details/scenario :
//Validate deactivated employee details should update in Oracle

public class WD11 {

}
