package com.ofap.testcases.murex;

import java.io.IOException;

import com.ofap.base.globalLibrary;
import com.ofap.xlsxcsv.ExportToCSV;

public class Murex_Test  extends globalLibrary
{
	ExportToCSV csv = new ExportToCSV();
	
	public void exportToCSVHeader() throws IOException
	{
		csv.exportToCSVHeader();
		
	}
}
