package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-06
//Test Case Details/scenario :
//Validate workday change in Legal employer picked up by Oracle

public class WD06 {

}
