package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-13
//Test Case Details/scenario :
//Validate Oracle application behaviour when WD created file got corrupted or with Junk file

public class WD13 {

}
