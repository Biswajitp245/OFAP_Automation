package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-08
//Test Case Details/scenario :
//Validate workday change in Manager Assignment picked up by Oracle


public class WD08 {

}
