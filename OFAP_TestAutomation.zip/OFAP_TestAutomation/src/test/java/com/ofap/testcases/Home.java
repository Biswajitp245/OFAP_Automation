package com.ofap.testcases;

import java.util.Hashtable;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.ChangeDataAccessSet;
import com.ofap.pages.CreateJournal;
import com.ofap.pages.HomePage;
import com.ofap.pages.Journals;
import com.ofap.utilities.TestUtil;

public class Home extends globalLibrary
{
	HomePage hp = new HomePage();
	ChangeDataAccessSet das = new ChangeDataAccessSet();
	CreateJournal cj = new CreateJournal();
	Journals j = new Journals();
	
	@Test(priority=1)
	//@Test(dependsOnMethods = {"doLoginTest"})
	public void home() throws InterruptedException
	{
		hp.homeIcon();

	}
	
	/*
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void createJournalSave(Hashtable<String,String> data) throws InterruptedException
	{
		if(!data.get("select_le").equals("Y"))
		{
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		
		hp.select("CJLegar_Entry_Name_XPATH",data.get("legalentity"));
		Thread.sleep(10000);
		
		if(!data.get("select_c").equals("Y"))
		{
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		hp.select("CJCategory_XPATH",data.get("category"));
	}
	*/
} 




