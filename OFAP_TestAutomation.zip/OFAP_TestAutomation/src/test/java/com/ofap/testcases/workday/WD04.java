package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-04
//Test Case Details/scenario :
//Validating WD generated employee register pickup by Oracle GL daily basis

public class WD04 {

}
