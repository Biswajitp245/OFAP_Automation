package com.ofap.testcases;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.NoSuchElementException;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.utilities.TestUtil;
import com.relevantcodes.extentreports.LogStatus;

public class Login extends globalLibrary 
{
	/*
	 * Login Functionality, Credential are from Excel Sheet.
	 */
	globalLibrary gl = new globalLibrary();

	@Test(priority=0,dataProviderClass=TestUtil.class,dataProvider="dp")
	public void doLoginTest(Hashtable<String,String> data) throws InterruptedException
	{
	gl.login();
	try
	{
	  if(!data.get("runmode").equals("Y"))
		{
			 
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		
		System.setProperty("test-output", "false");
		Reporter.log("Inside the Login Page !!!");
		log.debug("Inside the Login Page !!!");
		log.debug("Enter User Name !!!");
		gl.writeText("userID_XPATH",data.get("username"));
		log.debug("Enter User Password !!!");
		gl.writeText("userPwd_XPATH",data.get("password"));
		log.debug("Click on Sign-In button");
		gl.click("signIn_XPATH");
		Reporter.log("Login Successfully Done !!!");
		//Thread.sleep(2000);
		gl.isElementPresent("verifyLogin_XPATH");
		
		//test.log(LogStatus.PASS, "Login Credential Mismatching:   ");
	}catch (NoSuchElementException e) 
	{
		try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) 
			{
			e1.printStackTrace();
			}
		//Extent Reports
		test.log(LogStatus.FAIL, "Authentication Failed. Due To Login Credential Mismatch:   " + e.getMessage());
		test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
	}	
		
	
//******************************************************************************************************************
	
	/*
	// @Test(priority=0,dataProviderClass=TestUtil.class,dataProvider="dp")

	@Test
	public void doLoginTest() 
	{

		gl.login();

		Reporter.log("Inside the Login Page !!!");
		log.debug("Inside the Login Page !!!");
		log.debug("Enter User Name !!!");
		String userName = excel.getCellData("doLoginTest", "username", 2);
		gl.writeText("userID_XPATH", userName);

		log.debug("Enter User Password !!!");
		String password = excel.getCellData("doLoginTest", "password", 2);
		gl.writeText("userPwd_XPATH", password);
		log.debug("Click on Sign-In button");
		gl.click("signIn_XPATH");
		Reporter.log("Login Successfully Done !!!");
		// Thread.sleep(2000);
		gl.isElementPresent("verifyLogin_XPATH");
		
	}
	*/
	}
}
