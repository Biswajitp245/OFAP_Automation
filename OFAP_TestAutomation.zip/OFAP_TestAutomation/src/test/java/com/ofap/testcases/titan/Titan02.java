package com.ofap.testcases.titan;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ofap.base.TestBase;
import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.titan.AccountHeadDetails;
import com.ofap.pages.titan.ReviewJournal;
import com.relevantcodes.extentreports.LogStatus;


public class Titan02 extends TestBase
{
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	ReviewJournal rj = new ReviewJournal();
	AccountHeadDetails acchead = new AccountHeadDetails();
	
	
	@BeforeTest
	public void titan() throws InterruptedException, IOException, ParseException
	{
		String testcase01 = excel.getCellData("test_suite", "TestCaseName", 4);
		test.log(LogStatus.INFO, "Name of the Test Case Titan 02   :       " + testcase01);
	  	
		hp.homeIcon(); //Click on Home Icon
		hp.generalAccountingJournals();  //Click on Journal Icon
		hp.taskIcon();	//Click on Task Icon
		gl.veriticalScroll();
		gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
	
	}
	
	
	@AfterTest
	public void tita() throws InterruptedException, IOException, ParseException
	{
		gl.click("ReviewButtonDone_XPATH");
		test.log(LogStatus.INFO, "Back to the Journal Page   :  By Clicking Review Button     ");
	
	}
	
	//@Test(dependsOnMethods = {"doLoginTest"})
	@Test(priority=2)//(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void titan01() throws InterruptedException, IOException, ParseException, ClassNotFoundException, SQLException
	{

		rj.transactionSearch(); //After giving input click on Search Button
		rj.reviewJournalEntry();
		rj.reviewTransactionEntry();
		rj.verifyTransactionHeader();
		rj.clickDone();
		rj.viewSupportingReferences();
		rj.clickDone();
		rj.verifyJournalLineDrCrTotal();
		rj.clickDone();
	}
}
