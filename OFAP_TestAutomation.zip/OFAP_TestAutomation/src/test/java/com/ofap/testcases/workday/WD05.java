package com.ofap.testcases.workday;

//JIRA No. : OFAP-1022
//Test Case ID: WD-05
//Test Case Details/scenario :
//Validate New employee entry picked up by Oracle GL


public class WD05 {

}
