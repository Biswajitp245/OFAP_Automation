package com.ofap.testcases.titan;

import java.io.IOException;
import java.text.ParseException;

import org.testng.annotations.Test;

import com.ofap.base.TestBase;
import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.titan.AccountHeadDetails;
import com.ofap.pages.titan.ReviewJournal;
import com.relevantcodes.extentreports.LogStatus;


public class Titan01 extends TestBase
{
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	ReviewJournal rj = new ReviewJournal();
	AccountHeadDetails acchead = new AccountHeadDetails();
	
	//@Test(dependsOnMethods = {"doLoginTest"})
	@Test//(dataProviderClass=TestUtil.class,dataProvider="dp")
	//@Test(threadPoolSize = 3, invocationCount = 2,  timeOut = 10000)
	public void titan01() throws InterruptedException, IOException, ParseException
	{
		String testcase01 = excel.getCellData("test_suite", "TestCaseName", 4);
		test.log(LogStatus.INFO, "Name of the Test Case Titan 01   :       " + testcase01);
	  	
		hp.homeIcon(); //Click on Home Icon
		hp.generalAccounting();  //Click on General Accounting Icon
		hp.generalAccountingJournals();  //Click on Journal Icon
		hp.taskIcon();	//Click on Task Icon
		gl.veriticalScroll();
		gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
		
		rj.reviewJournalEntrySearch(); //After giving input click on Search Button
		rj.reviewJournalEntry(); //Validate (Ledger, Status, Accounting Date, Journal Category.
		
		rj.reviewTransactionEntry();
		rj.verifyTransactionHeader();
//		acchead.lineAccountCount();
		rj.verifyTransactionLines();
		rj.verifyJournalLineDrCrTotal();
		acchead.lineAccountCount();
		rj.viewSupportingReferences();
		//rj.journalLineSupportReferenceImgBack();
		//rj.journalLineAccount();
		rj.verifyTransactionLines();
		acchead.accountHeadDetails();
	}
}
