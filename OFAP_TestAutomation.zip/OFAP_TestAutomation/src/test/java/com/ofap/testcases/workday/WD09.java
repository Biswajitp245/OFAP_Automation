package com.ofap.testcases.workday;

//JIRA No. : OFAP-1023
//Test Case ID: WD-09
//Test Case Details/scenario :
//Validate workday change in Location picked up by Oracle

public class WD09 {

}
