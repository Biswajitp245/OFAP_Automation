package com.ofap.testcases.workday;

//JIRA No. : OFAP-1023
//Test Case ID: WD-10
//Test Case Details/scenario :
//Validate workday change in cost center has picked by Oracle

public class WD10 {

}
