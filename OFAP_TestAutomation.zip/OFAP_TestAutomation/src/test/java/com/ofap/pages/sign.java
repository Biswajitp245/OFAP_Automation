package com.ofap.pages;

import java.io.IOException;

import com.ofap.base.globalLibrary;

public class sign extends globalLibrary
{
	globalLibrary gl = new globalLibrary();

	//Validate or Click on [Review Journal Entry] Button Functionality.
	public void reviewJournalEntry_Btn() throws IOException
	{
		gl.isElementPresent("ReviewButtonViewJournalEntry_XPATH");
		gl.waitClick("ReviewButtonViewJournalEntry_XPATH");
	}

	//Validate or Click on [Review Transaction Entry] Button Functionality
	public void reviewTransactionEntry_Btn() throws InterruptedException
	{
		Thread.sleep(2000);
		gl.click("ReviewButtonViewTransaction_XPATH");
		log.debug("Click on View Transaction Button ");
		return;
	}

	//Click on [Done] Button Functionality.
	public void clickDone_Btn() throws IOException
	{
		gl.isElementPresent("ButtonDone_XPATH");
		gl.click("ButtonDone_XPATH");
	}
}
