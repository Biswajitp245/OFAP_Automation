package com.ofap.pages.murex;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.utilities.TestUtil;
import com.relevantcodes.extentreports.LogStatus;

//Verify all the Data e.g. (Application Name, Event Type, Ledger, Transaction Date,	Transaction Number) etc....
///table/tbody/tr[1]/td[2]/div/table/tbody/tr
//table[@class='x1no x1oc'][@summary='Lines']/tbody/tr[1]/td[2]/div/table/tbody/tr
public class TransactionLine_Murex extends globalLibrary 
{
	public static WebElement htmltable;
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void verifyTransactionLine() throws IOException
	{
		htmltable= driver.findElement(By.xpath("//table[@class='x1no x1oc'][@summary='Lines']"));
		List<WebElement> rows = htmltable.findElements(By.tagName("tbody"));
		//List<WebElement> rows = htmltable.findElements(By.xpath("//table[@class='x1no x1oc'][@summary='Lines']/tbody"));
		  System.out.println("Number of rows=> TransactionLine => "+rows.size());  
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  //List<WebElement> columns = rows.get(rnum).findElements(By.tagName("tbody")); 
			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//table[@class='x1no x1oc'][@summary='Lines']/tbody/tr[1]/td[2]/div/table/tbody/tr/td")); 
			  System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=0;cnum<columns.size();cnum++) 
			  { 
				  String a0 = columns.get(0).getText();
				  String a1 = columns.get(1).getText();
				  String a12 = columns.get(12).getText();
				  String a13 = columns.get(13).getText();
				  String a14 = columns.get(14).getText();
				  //System.out.println(actual_applicationName);
				  System.out.println(a0 + "\n" +a12);
				  System.out.println(a13);
				  System.out.println(a14);
//				  String expect_applicationName = excel.getCellData("tranLineMurex", "LineNumber", cnum);
	//			  gl.verifyEquals(expect_applicationName, actual_applicationName);
				  test.log(LogStatus.INFO, "TransactionLine "  + a0);
			//	  log.debug("Verify Line No  : Expected: " + expect_applicationName + "  Actual Name:   " + actual_applicationName);
			  }
		  }
	}
}
