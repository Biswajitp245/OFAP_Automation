package com.ofap.pages.titan;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.utilities.TestUtil;
import com.relevantcodes.extentreports.LogStatus;


public class ReviewJournal extends globalLibrary 
{
	public static WebElement htmltable;
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	RiewSupportingReferenceImg img = new RiewSupportingReferenceImg();
	AccountHeadDetails acchead = new AccountHeadDetails();
	 
	
	//Review Journal Entry Line- Search Functionality [Inputs are Ledger, Journal Source, Date and Transaction Number
	public void transactionSearch() throws InterruptedException, IOException, ParseException, SQLException 
	{
		
		gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
		log.debug("Select Ledger from the Dropdown");
		gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
		log.debug("Select Journal Source from the Dropdown");
		gl.click("ReviewDropDownTextJournalSource_XPATH");
		Thread.sleep(1000);
		//Select Application Name Excel and  tranHeader workbook
		int rowCount = excel.getRowCount("tranHeader");
		
		System.out.println("Total No of Rows  tranHeader:    "+ rowCount);
		for(int rnum=2;rnum<=rowCount;rnum++) 
		  {
			
			Thread.sleep(1000);
			String appName = excel.getCellData("tranHeader", "applicationName", rnum);
			System.out.println("Row Starts from :     "+ rnum + "Data :   " + appName);
			gl.textClear("ReviewDropDownTextJournalSource_XPATH");
			gl.writeText("ReviewDropDownTextJournalSource_XPATH", appName);
			Thread.sleep(1000);  
			//gl.isElementPresent("ReviewDropDatePickerFromDate_XPATH");
			gl.click("ReviewDropDatePickerFromDate_XPATH");
			gl.textClear("ReviewDropDatePickerFromDate_XPATH");
			Thread.sleep(1000);

			gl.writeText("ReviewDropDatePickerFromDate_XPATH", "12/30/19");
				
			gl.click("ReviewTextJournalSourceTransaction_XPATH");
			
			Thread.sleep(1000);
			String tranValue = excel.getCellData("tranHeader", "transactionNumber", rnum);
			long tranNum=Long.parseLong(tranValue);
			System.out.println("Row Starts from :     "+ rnum + "   Transaction Number is:   " + tranNum);
			//gl.textClear("ReviewTextJournalSourceTransaction_XPATH");
			//gl.writeText("ReviewTextJournalSourceTransaction_XPATH", tranNum);
			driver.findElement(By.xpath("ReviewTextJournalSourceTransaction_XPATH")).sendKeys("tranNum");
			gl.click("PMSearchButtonSearch_XPATH");
			
			
			Thread.sleep(3000);
			//gl.click("SearchExpand_XPATH");	//Click on Search Expand Icon.
			//gl.click("ReviewButtonDone_XPATH");	//Click on Done Button.
			//hp.taskIcon();	//Click on Task Icon
			//gl.veriticalScroll();
			//gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
			
			//gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
			//log.debug("Select Ledger from the Dropdown");
			//gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
			//log.debug("Select Journal Source from the Dropdown");
			//gl.click("ReviewDropDownTextJournalSource_XPATH");
			//Thread.sleep(1000);
		
		  }
	
	}
	
	//Review Journal Entry Line- Search Functionality [Inputs are Ledger, Journal Source, Date and Transaction Number
		public void transactionSearchMurex() throws InterruptedException, IOException, ParseException 
		{
			gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
			log.debug("Select Ledger from the Dropdown");
			gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
			log.debug("Select Journal Source from the Dropdown");
			gl.click("ReviewDropDownTextJournalSourceMurex_XPATH");
			Thread.sleep(1000);
			//Select Application Name Excel and  tranHeader workbook
			int rowCount = excel.getRowCount("tranHeaderMurex");
			
			System.out.println("Total No of Rows  tranHeaderMurex:    "+ rowCount);
			for(int rnum=2;rnum<=rowCount;rnum++) 
			  {
				
				Thread.sleep(1000);
				String appName = excel.getCellData("tranHeaderMurex", "applicationName", rnum);
				System.out.println("Row Starts from :     "+ rnum + "Data :   " + appName);
				gl.textClear("ReviewDropDownTextJournalSource_XPATH");
				gl.writeText("ReviewDropDownTextJournalSource_XPATH", appName);
				Thread.sleep(1000);  
				//gl.isElementPresent("ReviewDropDatePickerFromDate_XPATH");
				gl.click("ReviewDropDatePickerFromDate_XPATH");
				gl.textClear("ReviewDropDatePickerFromDate_XPATH");
				Thread.sleep(1000);

				gl.writeText("ReviewDropDatePickerFromDate_XPATH", "12/30/19");
						
				//String tranNum = excel.getCellData("tranHeaderMurex", "transactionNumber", rnum);
				//System.out.println("Row Starts from :     "+ rnum + "   Data :   " + tranNum);
				gl.textClear("ReviewTextJournalSourceTransaction_XPATH");
				gl.writeText("ReviewTextJournalSourceTransaction_XPATH", "131903805");
				
				gl.click("PMSearchButtonSearch_XPATH");
				
				
				Thread.sleep(3000);
				//gl.click("SearchExpand_XPATH");	//Click on Search Expand Icon.
				//gl.click("ReviewButtonDone_XPATH");	//Click on Done Button.
				//hp.taskIcon();	//Click on Task Icon
				//gl.veriticalScroll();
				//gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
				
				//gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
				//log.debug("Select Ledger from the Dropdown");
				//gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
				//log.debug("Select Journal Source from the Dropdown");
				//gl.click("ReviewDropDownTextJournalSource_XPATH");
				//Thread.sleep(1000);
			
			  }
		
		}
		
	//After Giving Input Button Validate Search Button
	public void reviewJournalEntrySearch() throws InterruptedException, IOException, ParseException 
	{
		gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
		log.debug("Select Ledger from the Dropdown");
		gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
		log.debug("Select Journal Source from the Dropdown");
		gl.click("ReviewDropDownTextJournalSource_XPATH");
		Thread.sleep(1000);
		//Select Application Name Excel and  tranHeader workbook
		gl.writeText("ReviewDropDownTextJournalSource_XPATH", excel.getCellData("tranHeader", "applicationName", 2));
		gl.isElementPresent("ReviewDropDatePickerFromDate_XPATH");
		gl.click("ReviewDropDatePickerFromDate_XPATH");
		Thread.sleep(1000);
		gl.textClear("ReviewDropDatePickerFromDate_XPATH");
		Thread.sleep(1000);
	
		/*
		 * SimpleDateFormat formatter = new SimpleDateFormat("m/d/yy"); 
		 * String localdate = excel.getCellData("tranHeader", "transactionDate", 2);
		 * System.out.println(localdate); 
		 * Date date = formatter.parse(localdate); 
		 * String formattedDateString = formatter.format(date);
		 * System.out.println(formattedDateString);
		 * gl.writeText("ReviewDropDatePickerFromDate_XPATH", formattedDateString);
		 */
		
		gl.writeText("ReviewDropDatePickerFromDate_XPATH", "12/30/19");
		
		gl.writeText("ReviewTextJournalSourceTransaction_XPATH", excel.getCellData("tranHeader", "transactionNumber", 2));
		Thread.sleep(1000);
		gl.isElementPresent("PMSearchButtonSearch_XPATH");
		log.debug("Element is Presented in the current page ");
		gl.click("PMSearchButtonSearch_XPATH");
		Thread.sleep(3000);
		gl.click("SearchExpand_XPATH");	//Click on Search Expand Icon.
	}
	
	
	
	//Validate or Click on [Review Journal Entry] Button Functionality.
	public void reviewJournalEntry() throws IOException
	{
		gl.isElementPresent("ReviewButtonViewJournalEntry_XPATH");
		gl.waitClick("ReviewButtonViewJournalEntry_XPATH");
	}
	
	//Validate or Click on [Review Transaction Entry] Button Functionality
	public void reviewTransactionEntry() throws InterruptedException
	{
		Thread.sleep(2000);
		gl.click("ReviewButtonViewTransaction_XPATH");
		log.debug("Click on View Transaction Button ");
		return;
	}
	
	//Validate or Click on [Review Journal Entry] Button Functionality.
	public void clickDone() throws IOException
	{
		gl.isElementPresent("ButtonDone_XPATH");
		gl.click("ButtonDone_XPATH");
	}
	
	
	//Verify Account Date and Report Date Should be Same.
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void verifyAccountAndReportDate() throws InterruptedException
	{
			
	}
		
	//Verify all the Data e.g. (Application Name, Event Type, Ledger, Transaction Date,	Transaction Number) etc....
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void verifyTransactionHeader() throws IOException
	{
		htmltable= driver.findElement(By.xpath("//div[@class='x1nn'][contains(@id,'hdrTbl')]"));
		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
		  System.out.println("Number of rows:"+rows.size());  
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//td[@class='xeq']")); 
			  //System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=2;cnum<columns.size();cnum++) 
			  { 
				  String actual_applicationName = columns.get(0).getText();
				  String expect_applicationName = excel.getCellData("tranHeader", "applicationName", cnum);
				  gl.verifyEquals(expect_applicationName, actual_applicationName);
				  test.log(LogStatus.INFO, "Verify Application Name : Expected: " + expect_applicationName + "   Actual Name:   " + actual_applicationName);
				  log.debug("Verify Application Name : Expected: " + expect_applicationName + "  Actual Name:   " + actual_applicationName);
				  	
				  String actual_eventType = columns.get(1).getText();
				  String expect_eventType = excel.getCellData("tranHeader", "eventType", cnum);
				  gl.verifyEquals(expect_eventType, actual_eventType);
				  test.log(LogStatus.INFO, "Verify EventType : Expected: " + expect_eventType + "  Actual EventType:   " + actual_eventType);
				  log.debug("Verify EventType : Expected: " + expect_eventType + "  Actual EventType:   " + actual_eventType);

				  String actual_ledger = columns.get(2).getText();
				  String expect_ledger = excel.getCellData("tranHeader", "ledger", cnum);
				  gl.verifyEquals(expect_ledger, actual_ledger);
				  test.log(LogStatus.INFO, "Verify Ledger Name : Expected: " + expect_ledger + "  Actual Ledger Name:   " + actual_ledger);
				  log.debug("Verify Ledger Name : Expected: " + expect_ledger + "  Actual Ledger Name:   " + actual_ledger);
				  	
				  String actual_transactionDate = columns.get(3).getText();
				  String expect_transactionDate = excel.getCellData("tranHeader", "transactionDate", cnum);
				  gl.verifyEquals(expect_transactionDate, actual_transactionDate);
				  test.log(LogStatus.INFO, "Verify Transaction Date : Expected: " + expect_transactionDate + "  Actual Transaction Date:   " + actual_transactionDate);
				  log.debug("Verify Transaction Date : Expected: " + expect_transactionDate + "  Actual Transaction Date:   " + actual_transactionDate);
					
				  String actual_transactionNumber = columns.get(4).getText();
				  String expect_transactionNumber = excel.getCellData("tranHeader", "transactionNumber", cnum);
				  gl.verifyEquals(expect_transactionNumber, actual_transactionNumber);
				  test.log(LogStatus.INFO, "Verify Transaction Number : Expected: " + expect_transactionNumber + "  Actual Transaction Number:   " + actual_transactionNumber);
				  log.debug("Verify Transaction Number : Expected: " + expect_transactionNumber + "  Actual Transaction Number:   " + actual_transactionNumber);
					
				  //String actual_MMI_ID_T = columns.get(5).getText();
				  //String expect_MMI_ID_T = excel.getCellData("tranHeader", "MMI_ID_T", cnum);
				  //gl.verifyEquals(expect_MMI_ID_T, actual_MMI_ID_T);
				  //test.log(LogStatus.INFO, "Verify MMI_ID_T : Expected: " + expect_MMI_ID_T + "  Actual MMI_ID_T:   " + actual_MMI_ID_T);
				  //log.debug("Verify MMI_ID_T : Expected: " + expect_MMI_ID_T + "  Actual MMI_ID_T:   " + actual_MMI_ID_T);
					
				  String actual_RPTG_DT_T = columns.get(6).getText();
				  String expect_RPTG_DT_T = excel.getCellData("tranHeader", "RPTG_DT_T", cnum);
				  gl.verifyEquals(expect_RPTG_DT_T, actual_RPTG_DT_T);
				  test.log(LogStatus.INFO, "Verify RPTG_DT_T : Expected: " + expect_RPTG_DT_T + "  Actual RPTG_DT_T:   " + actual_RPTG_DT_T);
				  log.debug("Verify RPTG_DT_T : Expected: " + expect_RPTG_DT_T + "  Actual RPTG_DT_T:   " + actual_RPTG_DT_T);
					
				  //String actual_TI_INV_NO_T = columns.get(7).getText();
				  //String expect_TI_INV_NO_T = excel.getCellData("tranHeader", "TI_INV_NO_T", cnum);
				  //gl.verifyEquals(expect_TI_INV_NO_T, actual_TI_INV_NO_T);
				  //test.log(LogStatus.INFO, "Verify TI_INV_NO_T : Expected: " +expect_TI_INV_NO_T+ "  Actual TI_INV_NO_T:   " + actual_TI_INV_NO_T);
				  //log.debug("Verify TI_INV_NO_T : Expected: " +expect_TI_INV_NO_T+ "  Actual TI_INV_NO_T:   " + actual_TI_INV_NO_T);
					
				  //String actual_PERIOD_T = columns.get(8).getText();
				  //String expect_PERIOD_T = excel.getCellData("tranHeader", "PERIOD_T", cnum);
				  //gl.verifyEquals(expect_PERIOD_T, actual_PERIOD_T);
				  //test.log(LogStatus.INFO, "Verify PERIOD_T : Expected: " + expect_PERIOD_T + "  Actual PERIOD_T:   " + actual_PERIOD_T);
				  //log.debug("Verify PERIOD_T : Expected: " + expect_PERIOD_T + "  Actual PERIOD_T:   " + actual_PERIOD_T);
					
				  String actual_LEGAL_ENTITY_NAME_T = columns.get(9).getText();
				  String expect_LEGAL_ENTITY_NAME_T = excel.getCellData("tranHeader", "LEGAL_ENTITY_NAME_T", cnum);
				  gl.verifyEquals(expect_LEGAL_ENTITY_NAME_T, actual_LEGAL_ENTITY_NAME_T);
				  test.log(LogStatus.INFO, "Verify LEGAL_ENTITY_NAME_T Name : Expected: " + expect_LEGAL_ENTITY_NAME_T + "  Actual LEGAL_ENTITY_NAME_T:   " + actual_LEGAL_ENTITY_NAME_T);
				  log.debug("Verify LEGAL_ENTITY_NAME_T Name : Expected: " + expect_LEGAL_ENTITY_NAME_T + "  Actual LEGAL_ENTITY_NAME_T:   " + actual_LEGAL_ENTITY_NAME_T);
				  	
				  String actual_LEDG_IND_T = columns.get(10).getText();
				  String expect_LEDG_IND_T = excel.getCellData("tranHeader", "LEDG_IND_T", cnum);
				  gl.verifyEquals(expect_LEDG_IND_T, actual_LEDG_IND_T);
				  test.log(LogStatus.INFO, "Verify LEDG_IND_T : Expected: " + expect_LEDG_IND_T + "  Actual LEDG_IND_T:   " + actual_LEDG_IND_T);
				  log.debug("Verify LEDG_IND_T : Expected: " + expect_LEDG_IND_T + "  Actual LEDG_IND_T:   " + actual_LEDG_IND_T);

				  break; 
			  } 
		  }
	}
	
	//Validate (Ledger, Status, Accounting Date, Journal Category.
	public void verifyJournalEntryDetails() throws IOException
	{
		//Validate (Ledger, Status, Accounting Date, Journal Category.
		String actual_Ledger = "";
		String expect_Ledger = excel.getCellData("journalDetails", "ledger", 2);
		gl.verifyEquals(expect_Ledger, actual_Ledger);
		log.debug("Veriry Application Name : Expected: " + expect_Ledger + "  Actual Name:   " + actual_Ledger);
	}
	
	//Verify all the Data e.g. (All the Account Heads) etc....
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void verifyTransactionLines() throws InterruptedException, IOException
	{
		gl.click("ReviewButtonDone_XPATH");
		
		//gl.mouseHoverWebTableRead("");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Account']")).click();
		
		htmltable= driver.findElement(By.xpath("//*[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:2:AP1:AT1:_ATp:table1::db']/table/tbody"));
		//htmltable= driver.findElement(By.xpath("//table[@class='x1no x1oc'][@summary='Subledger Journal Lines']"));
		
		List<WebElement> rows = htmltable.findElements(By.xpath("//tr[@class='xep']"));
		  System.out.println("Number of rows:"+rows.size());
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td")); 
			  System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=0;cnum<columns.size();cnum++) 
			  { 
				  String actual_applicationName = columns.get(0).getText();
				  //	log.debug("Veriry Application Name : Expected: " + expect_applicationName + "  Actual Name:   " + actual_applicationName);
				System.out.println("Number of columns:     "+ actual_applicationName);
				  break; 
			  } 
		  }

	}
	
	//Verify Journal Line Debit and Credit Total Should Match
	public void verifyJournalLineDrCrTotal() throws IOException, InterruptedException
	{
		try {
		List<WebElement> htmltable= driver.findElements(By.xpath("//span[@class='xmo']"));
		  System.out.println("Number of Records in Column is:  "+htmltable.size());
		  
		  for(int rnum=0;rnum<htmltable.size();rnum++) 
		  { 
			  String JGTotalDrFooter = htmltable.get(1).getText();
			  String JGTotalCrFooter = htmltable.get(2).getText();
			  
			  if(JGTotalDrFooter.equals(JGTotalCrFooter))
			  test.log(LogStatus.INFO, "Debit Total Amount: " + JGTotalDrFooter + "  Credit Total Amount:   " + JGTotalCrFooter);
			  log.debug("Debit Total Amount: " + JGTotalDrFooter + "  Credit Total Amount:   " + JGTotalCrFooter);
			  
		  }
		}catch (NoSuchElementException e) {
			
			TestUtil.captureScreenshot();
			// Extent Reports
			test.log(LogStatus.FAIL, " Verification failed with exception : " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		
		}
		
		Thread.sleep(20000);

	}
	
	//Click on each Image Icon
		@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
		public void viewSupportingReferences() throws InterruptedException, IOException
		{
			driver.findElement(By.xpath("//span[text()='Supporting References']")).click();
			
			List<WebElement> htmltable= driver.findElements(By.xpath("//a/img[contains(@title,'View Supporting References')]"));
			int i = htmltable.size(); 
			System.out.println("Number of rows: View Supporting References :   "+ i);
			  
			
			for(int rnum=0;rnum<=i;rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  
				  htmltable.get(rnum).click();  //Click on View Supporting Reference First Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTable_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountZero();
					    	acchead.accountHeadDetails();
					 }
				  
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineOne_XPATH"))
						 {
						    	Thread.sleep(1000);
							 img.supportReferenceImage1();
						 }
				      break;
			 }   
			  Thread.sleep(1000);
			  for(int rnum=1;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(1).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableOne_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountOne();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineTwo_XPATH"))
						 {
						 img.supportReferenceImage2();
						 }
				      break;
			  }  
			  Thread.sleep(1000);
			  for(int rnum=2;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(2).click();  //Click on View Supporting Reference Second Icon
				  
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableTwo_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountTwo();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineThree_XPATH"))
						 {
						 img.supportReferenceImage3();
						 }
				      break;
			  }  
			  Thread.sleep(1000);
			  for(int rnum=3;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(3).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableThree_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountThree();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineFour_XPATH"))
						 {
						 img.supportReferenceImage4();
						 }
				      break;
			  }  
			  Thread.sleep(1000);
			 
			  for(int rnum=4;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(4).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableFour_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountFour();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineFive_XPATH"))
						 {
						 img.supportReferenceImage5();
						 }
				      break;
			  }
			  
			  Thread.sleep(1000); 
			  for(int rnum=5;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(5).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableFive_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountFive();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineSix_XPATH"))
						 {
						 img.supportReferenceImage6();
						 }
				      break;
			  } 
			  
			  Thread.sleep(1000); 
			  for(int rnum=6;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(6).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableSix_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountSix();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineSeveen_XPATH"))
						 {
						 img.supportReferenceImage7();
						 }
				      break;
			  } 
			  
	 
			  Thread.sleep(1000); 
			  for(int rnum=7;rnum<htmltable.size();rnum++) 
			  { 
				  System.out.println("Number of rows: View Supporting References : Name  "+htmltable.get(rnum));
				  htmltable.get(7).click();  //Click on View Supporting Reference Second Icon
				  if (gl.isElementEnabled("MouseHoverAccountHeadTableSeveen_XPATH"))
					 {
					    	Thread.sleep(1000);
					    	acchead.mouseHoverAccountSeveen();
					    	acchead.accountHeadDetails();
					 }
				    	Thread.sleep(1000);
						 if (gl.isElementEnabled("JournalLineSupportingLineEight_XPATH"))
						 {
						 img.supportReferenceImage8();
						 }
				      break;
			  } 
				 
				 //break;
				 
				  
				/*  for (int i=0; i<=rnum; i++)
					{
						String start ="//button[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:2:AP1:AT1:_ATp:table1:";
						String end = ":d2::ok']";
						String JournalLineSupportingButtonDone_XPATH = start + (i+1) + end;
						
					  System.out.println(JournalLineSupportingButtonDone_XPATH);
					  //gl.isElementEnabled("JournalLineSupportingButtonDone_XPATH");
					  //gl.click("JournalLineSupportingButtonDone_XPATH");
					  driver.findElement(By.xpath(JournalLineSupportingButtonDone_XPATH)).click();
					} */

			 
		}
		

	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void journalLineSupportReference() throws InterruptedException
	{
		Thread.sleep(2000);
		gl.click("JournalLineSupportReferenceTable_XPATH");
		htmltable= driver.findElement(By.xpath("//table[contains(@summary,'Supporting References')]"));
		   
			List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
			//System.out.println("Number of rows : Journal Line Support Reference: "+rows.size());
			 for(int rnum=0;rnum<rows.size();rnum++) 
			  { 
				 List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td")); 
				  //System.out.println("Number of columns:"+columns.size()); 
				  for(int cnum=0;cnum<columns.size();cnum++) 
				  { 
					  String actual_ = columns.get(0).getText();
					 log.debug("Number of columns: Header Name :  " + actual_ );
					System.out.println("Number of columns: Header Name:   "+ actual_);
					  break; 
				  } 
			  }
	}
	
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void journalLineAccount() throws InterruptedException
	{
		Thread.sleep(2000);
		//Mouse Hover on Account Link Grid
		
		 // Actions action = new Actions(driver);  
		 // htmltable = driver.findElement(By.xpath("//span[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS2::content']")); 
		 // action.moveToElement(htmltable).build().perform(); 
		  //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]"))).click();

		  driver.findElement(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]")).click();	  
		  List<WebElement> rows=driver.findElements(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]//tbody/tr"));
			
			System.out.println("Number of rows:"+rows.size());
			

			for(int rnum=0;rnum<rows.size();rnum++)
			{
				//System.out.println("Row Wise Details are: "+rows.get(rnum).getText());
				
				List<WebElement> columns=rows.get(rnum).findElements(By.tagName("td"));
				//System.out.println("Number of columns:"+columns.size());
				for(int cnum=1;cnum<columns.size()-1;cnum++)
				{
					System.out.println(columns.get(cnum).getText());
					//excel.setCellData(value, RowNum, ColNum);
				}
	
			}
		
	}
	
}
