package com.ofap.pages;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class DataBaseFunctional extends globalLibrary
{
	private static Connection con = null;
	
		
}
