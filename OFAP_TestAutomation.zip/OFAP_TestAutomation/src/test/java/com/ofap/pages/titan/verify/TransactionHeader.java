package com.ofap.pages.titan.verify;

import java.io.IOException;
import java.text.ParseException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.pages.HomePage;
import com.ofap.pages.titan.ReviewJournal;

public class TransactionHeader extends globalLibrary
{
	HomePage hp = new HomePage();
	globalLibrary gl = new globalLibrary();
	ReviewJournal rj = new ReviewJournal();
	
	@BeforeTest
	public void titan() throws InterruptedException, IOException, ParseException
	{
		hp.homeIcon(); //Click on Home Icon
		hp.generalAccountingJournals();  //Click on Journal Icon	
		hp.taskIcon();	//Click on Task Icon
		gl.veriticalScroll();
		gl.waitClick("TaskReviewSubJournal_XPATH"); //Click on Review Sub-Journal Link
	
	}
	
	
	@AfterTest
	public void tita() throws InterruptedException, IOException, ParseException
	{
		//gl.click("ReviewButtonDone_XPATH");
		//test.log(LogStatus.INFO, "Back to the Journal Page   :  By Clicking Review Button     ");
	
	}
	
	//@Test(dependsOnMethods = {"doLoginTest"})
	@Test(priority=2)//(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void transactionHeader() throws InterruptedException, IOException, ParseException
	{

		gl.click("ReviewDropDownLedger_XPATH"); //Ledger select from the Dropdown Table.
		log.debug("Select Ledger from the Dropdown");
		gl.click("ReviewDropDownTextLedger_XPATH"); //Select any one from the list.
		log.debug("Select Journal Source from the Dropdown");
		gl.click("ReviewDropDownTextJournalSource_XPATH");
		Thread.sleep(1000);
		//Select Application Name Excel and  tranHeader workbook
		int rowCount = excel.getRowCount("tranHeader");
		
		System.out.println("Total No of Rows  tranHeader:    "+ rowCount);
		for(int rnum=2;rnum<=rowCount;rnum++) 
		  {
			
			Thread.sleep(1000);
			String appName = excel.getCellData("tranHeader", "applicationName", rnum);
			System.out.println("Row Starts from :     "+ rnum + "Data :   " + appName);
			gl.textClear("ReviewDropDownTextJournalSource_XPATH");
			gl.writeText("ReviewDropDownTextJournalSource_XPATH", appName);
			Thread.sleep(1000);  
			//gl.isElementPresent("ReviewDropDatePickerFromDate_XPATH");
			gl.click("ReviewDropDatePickerFromDate_XPATH");
			Thread.sleep(1000);
			gl.textClear("ReviewDropDatePickerFromDate_XPATH");
			Thread.sleep(1000);

			gl.writeText("ReviewDropDatePickerFromDate_XPATH", "12/30/19");
					
			String tranNum = excel.getCellData("tranHeader", "transactionNumber", rnum);
			System.out.println("Row Starts from :     "+ rnum + "   Data :   " + tranNum);
			gl.textClear("ReviewTextJournalSourceTransaction_XPATH");
			gl.writeText("ReviewTextJournalSourceTransaction_XPATH", tranNum);
			
			gl.click("PMSearchButtonSearch_XPATH");
			
			
			Thread.sleep(3000);
			rj.reviewJournalEntry(); //Click on [Review Journal Entry] Button
			rj.reviewTransactionEntry(); //Click on [View Transaction] Button
			rj.verifyTransactionHeader(); //Verify all the Transaction Header Data
		  }
	}
}
