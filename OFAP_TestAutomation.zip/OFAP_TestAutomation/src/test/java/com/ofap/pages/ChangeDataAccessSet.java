package com.ofap.pages;

import java.io.IOException;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.utilities.TestUtil;

public class ChangeDataAccessSet extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	HomePage hp = new HomePage();
	
	@Test(priority=1,dataProviderClass=TestUtil.class,dataProvider="dp")
	public void changeDataSet(Hashtable<String,String> data) throws InterruptedException
	{
		
		  if(!data.get("select").equals("Y")) 
		  {
		  
			  throw new SkipException("Pick one them from the List, If select option is 'Y'"); 
		  }
		 
		Reporter.log("Change Aceess Set is Present!!!");
		if (gl.isElementPresent("DAChangeSetText_XPATH"))
		{
			Reporter.log("Click on Change Aceess Set !!!");
			gl.click("DAChangeSet_XPATH");
			gl.waitWebElement("ChangeSetButtonOK_XPATH");
		}
		else
		{
			Reporter.log("Click on Change Aceess Set !!!");
			gl.click("DAChangeSet_XPATH"); 
			gl.click("ClickTable_XPATH");
			Reporter.log("Pick one them from the List !!!");
			gl.select("ChangeSetSelect_XPATH",data.get("accessset"));
			Thread.sleep(2000);
			gl.waitWebElement("ChangeSetButtonOK_XPATH");
		}
		
	}
}
