package com.ofap.pages.ifx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class VerifySearchResult extends globalLibrary
{
	public static WebElement htmltable;
	globalLibrary gl = new globalLibrary();
	
	public void verifySearchResult() throws IOException
	{
		htmltable= driver.findElement(By.xpath("//table[contains(@summary,'Daily Rates')]"));
		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
		  System.out.println("Number of rows:"+rows.size());  
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//table[contains(@summary,'Daily Rates')]//following::span[@class='x2s5']")); 
			  System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=0;cnum<columns.size();cnum++) 
			  { 
				  String actual_FromCurrency = columns.get(cnum).getText();
				  System.out.println("Act Cur    " + actual_FromCurrency);
				  String expect_ToCurrency = excel.getCellData("exchangeRate", "FromCurrency", cnum);
				  gl.verifyEquals(expect_ToCurrency, actual_FromCurrency);
				  test.log(LogStatus.INFO, "Verify Application Name : Expected: " + expect_ToCurrency + "   Actual Name:   " + actual_FromCurrency);
				  log.debug("Verify Application Name : Expected: " + expect_ToCurrency + "  Actual Name:   " + actual_FromCurrency);
			  }
		  }
	}
}
