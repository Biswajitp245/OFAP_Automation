package com.ofap.pages.titan;

import com.ofap.base.globalLibrary;

public class TitanJournal extends globalLibrary
	{
			globalLibrary gl = new globalLibrary();
			
			public void Ttian()
			{
				gl.waitClick("NavTitan_XPATH"); //Click on Titan Link
				
			}
			
			public void JournalSearch()
			{
					
			}

	} 

