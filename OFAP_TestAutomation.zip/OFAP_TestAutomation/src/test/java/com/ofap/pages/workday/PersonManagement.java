package com.ofap.pages.workday;

import java.io.IOException;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class PersonManagement extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	public void personMgmt()
	{
		gl.waitClick("NavPerMgmt_XPATH"); //Click on Person Management Link
		
	}
	
	public void employeeSearch()
	{
		log.debug("Click on Person Management Link  Icon Navigator List");
		gl.writeText("PMSearchTextName_XPATH", "Steve Madden");
		log.debug("Enter Employee Name on the Textbox");
		gl.click("PMSearchButtonSearch_XPATH");
		log.debug("Click on Search Button !!!");
		
		gl.scrollWebElement("PerMgmtScroll_XPATH"); //Scroll to View the element.
		
		gl.waitClick("PMSearchResultLinkEmployee_XPATH");
		log.debug("Click on Employee Link !!!");
	
	}
	
	public void employeeDetailsVerifyName() throws IOException
	{
		//Verify Madatory Fields : First Name, *Last Name
		int rowCount = excel.getRowCount("tranHeader");
		System.out.println("Total No Row or Records in PersonMgmt Sheet:    "+ rowCount);
		
		String lableName = gl.readText("PMSearchLevelName_XPATH", "");
		System.out.println("My Name is:  " + lableName);
		String []s1 = lableName.split(":");
		
			if (s1 != null && s1.length >0)
			{
				String []s2 = s1[0].split(" ");
				if(s2 != null)
				{
					String actual_FirstName= "", actual_LastName="", actual_LastName1="";
					
						actual_FirstName = s2[0];
						actual_LastName = s2[1];
						//actual_LastName1 = s2[2];
						
				System.out.println("First Name: " + actual_FirstName + "\n Middle Name: " + actual_LastName + "\n Last Name: " + actual_LastName1);
					//Count Total No Row or Records in PersonMgmt Sheet
				
					String expect_FirstName = excel.getCellData("PersonMgmt", "firstName", 2);
					gl.verifyEquals(expect_FirstName, actual_FirstName);
					test.log(LogStatus.INFO, "Verify First Name : Expected: " + expect_FirstName + "   Actual First Name:   " + actual_FirstName);
					log.debug("Verify First Name : Expected: " + expect_FirstName + "  Actual First Name:   " + actual_FirstName);
					
					String expectLastName = excel.getCellData("PersonMgmt", "lastName", 2);
					gl.verifyEquals(expectLastName, actual_LastName);
					test.log(LogStatus.INFO, "Verify Last Name : Expected: " + expectLastName + "   Actual Last Name:   " + actual_LastName);
					log.debug("Verify Last Name : Expected: " + expectLastName + "  Actual Last Name:   " + actual_LastName);
				  
				}
			}
	}
	
	public void employeeDetailsVerifyMandatoryData() throws IOException
	{
		//Verify Madatory Fields : *Email, *Hire Date, *Person Type
			
		int rowCount = excel.getRowCount("tranHeader");
		System.out.println("Total No Row or Records in PersonMgmt Sheet:    "+ rowCount);
		
		//String actual_eMail = gl.readText("PMSearchLevelName_XPATH", "");
		//System.out.println("My Name is:  " + actual_eMail);
		
		String actual_HireDate = gl.readText("PMSearchLevelHireDate_XPATH", "");
		System.out.println("Hire Date is:  " + actual_HireDate);
		
		String actual_PersonType = gl.readText("PMSearchLevelPersonType_XPATH", "");
		System.out.println("Name of Person Type is:  " + actual_PersonType);

		for(int rnum=2;rnum<=rowCount;rnum++) 
		{
			//String expect_eMail = excel.getCellData("PersonMgmt", "email", rnum);
			//gl.verifyEquals(expect_eMail, actual_eMail);
			//test.log(LogStatus.INFO, "Verify Employee eMail ID : Expected: " + expect_eMail + "   Actual First Name:   " + actual_eMail);
			//log.debug("Verify Employee eMail ID : Expected: " + expect_eMail + "  Actual eMail ID:   " + actual_eMail);
			
			String expect_HireDate = excel.getCellData("PersonMgmt", "hireDate", rnum);
			gl.verifyEquals(expect_HireDate, actual_HireDate);
			test.log(LogStatus.INFO, "Verify Employee Hire Date : Expected: " + expect_HireDate + "   Actual Hire Date:   " + actual_HireDate);
			log.debug("Verify Employee Hire Date : Expected: " + expect_HireDate + "  Actual Hire Date:   " + actual_HireDate);
			
			String expect_PersonType = excel.getCellData("PersonMgmt", "personType", rnum);
			gl.verifyEquals(expect_PersonType, actual_PersonType);
			test.log(LogStatus.INFO, "Verify Person Type : Expected: " + expect_PersonType + "   Actual Person Type:   " + actual_PersonType);
			log.debug("Verify Person Type : Expected: " + expect_PersonType + "  Actual Person Type:   " + actual_PersonType);
		}
	
	}
	
	public void employeeDetailsVerifyOther()
	{
		
	
	}
	
	
}
