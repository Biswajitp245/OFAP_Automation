package com.ofap.pages;

import org.openqa.selenium.By;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class HomePage extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	//@Test(dependsOnMethods = {"doLoginTest"})
	public void homeIcon()
	{
		gl.waitClick("HomeIcon_XPATH");
	}
	
	//@Test(dependsOnMethods = {"homeIcon"})
	public void generalAccounting()
	{
		gl.waitWebElement("HomeIconGenAcc_XPATH");
	}
	
	//@Test(dependsOnMethods = {"generalAccounting"})
	public void generalAccountingDashboard()
	{
		gl.waitClick("HIDashboard_XPATH");
	}
	
	//@Test(dependsOnMethods = {"generalAccounting"})
	public void generalAccountingJournals() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Journals']")).click();
		//gl.waitWebElement("HIJournals_XPATH");
		//gl.waitClick("HIJournals_XPATH");
	}
	
	//@Test(dependsOnMethods = {"generalAccounting"})
	public void generalAccountingPeriodClose()
	{
		gl.waitClick("HIPeriodClose_XPATH");
	}
	
	public void taskIcon()
	{
		gl.click("Task_XPATH");
		log.debug("Click on Task Icon");
	}
	
	public void navigator()
	{
		gl.click("HomeNavigator_XPATH");
		log.debug("Click on Navigator Icon from Home Page");
	}
	
	//
	public void setupMaintenance()
	{
		gl.click("HISetupMaintenance_XPATH");
		log.debug("Click on Setup and Maintenance Icon from Home Page");
	}
	
}




