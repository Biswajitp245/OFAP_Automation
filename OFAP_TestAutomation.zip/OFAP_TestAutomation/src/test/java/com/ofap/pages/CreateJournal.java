package com.ofap.pages;

import java.util.Hashtable;

import org.testng.SkipException;
import org.testng.annotations.Test;


import com.ofap.base.globalLibrary;
import com.ofap.utilities.TestUtil;

public class CreateJournal extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	
	public void clickJournalLink()
	{
		//gl.click("CJ_XPATH");
		gl.waitClick("CJ_XPATH");
	}
	
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
	public void createJournalSave(Hashtable<String,String> data) throws InterruptedException
	{
		if(!data.get("select_le").equals("Y"))
		{
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		
		gl.select("CJLegar_Entry_Name_XPATH",data.get("legalentity"));
		Thread.sleep(10000);
		
		if(!data.get("select_c").equals("Y"))
		{
			throw new SkipException("Skipping the test case as the Run mode for data set is NO");
		}
		gl.select("CJCategory_XPATH",data.get("category"));
	}
	
	public void createJournalSaveAndClose()
	{
		
	}
	
	public void createJournalSaveCloseAnother()
	{
		
	}
}
