package com.ofap.pages.murex;

import java.io.IOException;

import com.ofap.base.globalLibrary;

public class ReviewwSupportingReferenceImg_Murex extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	public void supportReferenceImage1() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineOne_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 2);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneOne_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneOne_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage2() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineTwo_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 3);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneTwo_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneTwo_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage3() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineThree_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 4);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneThree_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneThree_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage4() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineFour_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 5);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneFour_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneFour_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage5() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineFive_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 6);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneFive_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneFive_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage6() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineSix_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 7);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneSix_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneSix_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage7() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineSeveen_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 8);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneSeveen_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneSeveen_XPATH");
			  		
			}    
	}
	
	public void supportReferenceImage8() throws InterruptedException, IOException
	{
		String actual_Line =gl.readText("JournalLineSupportingLineEight_XPATH", "");
		String expect_Line = excel.getCellData("journalDetails", "JLSupportingReference", 9);
	
			if(actual_Line.equals(expect_Line))
			{
			  gl.isElementPresent("JournalLineSupportingButtonDoneEight_XPATH");
			  gl.waitClick("JournalLineSupportingButtonDoneEight_XPATH");
			  		
			}    
	}
	
	
}
