package com.ofap.pages.ifx;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class CurrencyRateManager extends globalLibrary
{
	public static WebElement dropdown;
	public static WebElement htmltable;
	
	globalLibrary gl = new globalLibrary();
	
	public void dailyRatesTab()
	{
		gl.click("SAFManageDailyRatesTab_XPATH"); //Click on Daily Rates Tab
	}
	
	public void dailyRates() throws InterruptedException
	{
		String fromCurrencyName = excel.getCellData("currencyMaster", "currency", 25); // Select From Currency
		gl.select("SAFFromCurrency_XPATH", fromCurrencyName);
		Thread.sleep(1000);
		
		String toCurrencyName = excel.getCellData("currencyMaster", "currency", 26);  // Select To Currency
		gl.select("SAFToCurrency_XPATH", toCurrencyName);
		
		gl.writeText("SAFFromRateDate_XPATH", "2/16/20"); //Type or Select From Date
		gl.writeText("SAFToRateDate_XPATH", "2/16/20"); //Type or Select To Date
		
		Thread.sleep(2000);
		gl.click("SAFSearchRateType_XPATH"); //select Search Type Drop-down
		gl.click("SAFSearchRateTypeCor_XPATH"); //select "Corporate" From the Drop-down list
		gl.click("SAFSearchButton_XPATH");  //Click on Search Button
		
		Thread.sleep(5000);
	}
	
	/* Dynamic but at the Run Time One of Date Column Remove from Excel Sheet
	public void verifyDailyRates() throws IOException
	{
		htmltable= driver.findElement(By.xpath("//table[contains(@summary,'Daily Rates')]"));
		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
		  System.out.println("Number of rows:"+rows.size());  
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//table[contains(@summary,'Daily Rates')]//following::span[@class='x2s5']")); 
			  System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=0;cnum<columns.size();cnum++) 
			  { 
				  int row=2;
				  String actual = columns.get(cnum).getText();
				  System.out.println("Actual   " + actual);
				  //String expect = excel.getCellData("exchangeRate", "FromCurrency", cnum);
				  String expect = excel.getCellData("exchangeRate", cnum, row);
				  row++;
				  System.out.println("expect    " + expect);
				  gl.verifyEquals(expect, actual);
			  }
		  }
	}
	
	*/
	//Verify Rates One by One Column (Excel- exchangeRate)
	public void verifyDailyRates() throws IOException
	{
		int rowCount = excel.getRowCount("exchangeRate");
		System.out.println("Total No of Rows in Exchange Rate Sheet:    "+ rowCount);
		
		htmltable= driver.findElement(By.xpath("//table[contains(@summary,'Daily Rates')]"));
		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
		  System.out.println("Number of rows:"+rows.size());  
		  for(int rnum=0;rnum<rows.size();rnum++) 
		  { 
			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//table[contains(@summary,'Daily Rates')]//following::span[@class='x2s5']")); 
			  System.out.println("Number of columns:"+columns.size()); 
			  for(int cnum=0;cnum<columns.size();cnum++) 
			  { 
				  int row=2;
				  
				  String actual_FromCurrency = columns.get(0).getText();
				  System.out.println("Actual   " + actual_FromCurrency);
				  String expect_FromCurrency = excel.getCellData("exchangeRate", "FromCurrency", row);
				  System.out.println("expect    " + expect_FromCurrency);
				  gl.verifyEquals(expect_FromCurrency, actual_FromCurrency);
				  test.log(LogStatus.INFO, "Verify From Currency : Expected: " + expect_FromCurrency + "  Actual From Currency:   " + actual_FromCurrency);
				  log.debug("Verify From Currency : Expected: " + expect_FromCurrency + "  Actual From Currency:   " + actual_FromCurrency);

				  
				  String actual_ToCurrency = columns.get(1).getText();
				  System.out.println("Actual   " + actual_ToCurrency);
				  String expect_ToCurrency = excel.getCellData("exchangeRate", "ToCurrency", row);
				  System.out.println("expect    " + expect_ToCurrency);
				  gl.verifyEquals(expect_ToCurrency, actual_ToCurrency);
				  test.log(LogStatus.INFO, "Verify To Currency : Expected: " + expect_ToCurrency + "  Actual To Currency:   " + actual_ToCurrency);
				  log.debug("Verify To Currency : Expected: " + expect_ToCurrency + "  Actual To Currency:   " + actual_ToCurrency);
 
				  String actual_FromDate = columns.get(2).getText();
				  System.out.println("Actual   " + actual_FromDate);
				  String expect_ToDate = excel.getCellData("exchangeRate", "FromDate", row);
				  System.out.println("expect    " + expect_ToDate);
				  gl.verifyEquals(expect_ToDate, actual_FromDate);
				  test.log(LogStatus.INFO, "Verify Rate Date : Expected: " + expect_ToDate + "  Actual Rate Date:   " + actual_FromDate);
				  log.debug("Verify Rate Date : Expected: " + expect_ToDate + "  Actual Rate Date:   " + actual_FromDate);

				  String actual_RateType = columns.get(3).getText();
				  System.out.println("Actual   " + actual_RateType);
				  String expect_RateType = excel.getCellData("exchangeRate", "ConversionType", row);
				  System.out.println("expect    " + expect_RateType);
				  gl.verifyEquals(expect_RateType, actual_RateType);
				  test.log(LogStatus.INFO, "Verify Rate Type : Expected: " + expect_RateType + "  Actual Rate Type:   " + actual_RateType);
				  log.debug("Verify Rate Type : Expected: " + expect_RateType + "  Actual Rate Type:   " + actual_RateType);

				  String actual_Rate = columns.get(4).getText();
				  System.out.println("Actual   " + actual_FromCurrency);
				  String expect_Rate = excel.getCellData("exchangeRate", "ConversionRate", row);
				  System.out.println("expect    " + expect_Rate);
				  gl.verifyEquals(expect_Rate, actual_Rate);
				  test.log(LogStatus.INFO, "Verify Rate : Expected: " + expect_Rate + "  Actual Rate:   " + actual_Rate);
				  log.debug("Verify Rate : Expected: " + expect_Rate + "  Actual Rate:   " + actual_Rate);

				  String actual_InversionRate = columns.get(5).getText();
				  System.out.println("Actual   " + actual_InversionRate);
				  String expect_InversionRate = excel.getCellData("exchangeRate", "InversionRate", row);
				  System.out.println("expect    " + expect_InversionRate);
				  gl.verifyEquals(expect_InversionRate, actual_InversionRate);
				  test.log(LogStatus.INFO, "Verify Inversion Rate: Expected: " + expect_InversionRate + "  Actual Inversion Rate:   " + actual_InversionRate);
				  log.debug("Verify Inversion Rate: Expected: " + expect_InversionRate + "  Actual Inversion Rate:   " + actual_InversionRate);
 
				  //row++;
			  }
		  }
	}
}
