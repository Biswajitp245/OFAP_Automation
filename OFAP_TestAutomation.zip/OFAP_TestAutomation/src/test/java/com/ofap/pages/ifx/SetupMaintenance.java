package com.ofap.pages.ifx;

import com.ofap.base.globalLibrary;

public class SetupMaintenance extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	public void dailyRatesLink() throws InterruptedException
	{
		gl.writeText("SAFSearchTasksTextBox_XPATH", "Daily Rates"); //1. Input value Daily Rates
		log.debug("Giving Input Text- Daily Rates");
		Thread.sleep(1000);
		gl.click("SAFSearchIcon_XPATH");  //2. Click on Search Icon
		gl.click("SAFManageDailyRatesLink_XPATH");  //3. Click on Manage Daily Rates link.
	}
}
