package com.ofap.pages;

import com.ofap.base.globalLibrary;

public class Journals extends globalLibrary
{
	globalLibrary gl = new globalLibrary();

	public void generalAccountingDashboard()
	{
		gl.waitClick("HIDashboard_XPATH");
	}
	
	public void generalAccountingPeriodClose()
	{
		gl.waitClick("HIPeriodClose_XPATH");
	}
	
	public void taskIcon()
	{
		gl.click("Task_XPATH");
	}
	
	public void requiringAttentionTab()
	{
		gl.click("JGRequrAttentionTab_XPATH");
		gl.click("JGRequrAttentionTableLinks_XPATH");
	}
	
	public void pendingApprovalOthersTab() 
	{
		gl.click("JGPendingAppOthTab_XPATH");
		gl.click("JGPendingAppOtherTableLinks_XPATH");
	}
	
	public void incompleteTab() 
	{
		gl.click("JGIncompleteTab_XPATH");
		gl.click("JGIncompleteTabLinks_XPATH");
	}
	
	public void importErrorsTab() 
	{
		gl.click("JGImportErrorsTab_XPATH");
		gl.click("JGImportErrorsTabLinks_XPATH");
	}
}
