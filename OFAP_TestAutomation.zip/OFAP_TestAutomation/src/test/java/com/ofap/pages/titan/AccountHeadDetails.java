package com.ofap.pages.titan;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.ofap.base.globalLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class AccountHeadDetails extends globalLibrary
{
	public static WebElement htmltable;
	globalLibrary gl = new globalLibrary();
	
	public void mouseHoverAccountZero()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTable_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTable_XPATH");
		}
	}
	
	public void mouseHoverAccountOne()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableOne_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableOne_XPATH");
		}
	}
	
	public void mouseHoverAccountTwo()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableTwo_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableTwo_XPATH");
		}
	}
	
	public void mouseHoverAccountThree()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableThree_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableThree_XPATH");
		}
	}
	
	public void mouseHoverAccountFour()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableFour_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableFour_XPATH");
		}
	}
	
	public void mouseHoverAccountFive()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableFive_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableFive_XPATH");
		}
	}
	
	public void mouseHoverAccountSix()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableSix_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableSix_XPATH");
		}
	}
	
	public void mouseHoverAccountSeveen()
	{
		if(gl.isElementPresent("MouseHoverAccountHeadTableSeveen_XPATH"))
		{
			gl.click("MouseHoverAccountHeadTableSeveen_XPATH");
		}
	}
	
	public void accountHeadDetails() throws IOException
	{
		//gl.mouseHoverWebTableRead("MouseHoverAccountHeadTableZero_XPATH");
		//gl.click("MouseHoverAccountHeadTableZero_XPATH");
		
		driver.findElement(By.xpath("//table[contains(@id,'Kff_hover_popTable')]")).click();	  
		  List<WebElement> rows=driver.findElements(By.xpath("//table[contains(@id,'Kff_hover_popTable')]//tbody/tr"));
			
			System.out.println("Number of rows:"+rows.size());
			

			for(int rnum=0;rnum<rows.size();rnum++)
			{
				System.out.println("Row Wise Details are: "+rows.get(rnum).getText());
				String segment = rows.get(rnum).getText();
				List<WebElement> columns=rows.get(rnum).findElements(By.tagName("td"));
				System.out.println("Number of columns:"+columns.size());
				for(int cnum=1;cnum<columns.size();cnum++)
				{
					System.out.println(columns.get(1).getText());
					 
			
					 String expect_LegalEntity = excel.getCellData("lineAccountHead", "Legal Entity", cnum);
				//	 excel.setCellData("lineAccountHead", rnum, cnum);
					 
				
					 
					 
					 //gl.verifyEquals(expect_LegalEntity, actual_LegalEntity);
					 //test.log(LogStatus.INFO, "Veriry Legal Entity : Expected: " + expect_LegalEntity + "   Actual Legal Entity:   " + actual_LegalEntity);
					 //log.debug("Veriry Legal Entity : Expected: " + expect_LegalEntity + "  Actual Legal Entity:   " + actual_LegalEntity);

				}
			}
	}
	
	public void lineAccountCount() throws IOException, InterruptedException
	{
		gl.click("ReviewButtonDone_XPATH");
		Thread.sleep(1000);
		gl.click("JournalLineAccountTable_XPATH");
		//gl.tableWebElement("JournalLineAccountTable_XPATH");
		htmltable= driver.findElement(By.xpath("//*[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:2:AP1:AT1:_ATp:table1::db']/table/tbody"));
		//htmltable= driver.findElement(By.xpath("//table[@class='x1no x1oc'][@summary='Subledger Journal Lines']"));
		
		List<WebElement> rows = htmltable.findElements(By.xpath("//tr[@class='xep']"));
		  System.out.println("Total No of Journal Lines Account is:  "+rows.size());
		  
		  test.log(LogStatus.INFO, "Total No of Journal Lines Account is:  " +  rows.size());
		  log.debug("Total No of Journal Lines Account is:  " +  rows.size());
	}
	
}
