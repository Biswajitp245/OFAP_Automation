package com.ofap.pages;

import com.ofap.base.globalLibrary;

public class EditJournal extends globalLibrary
{
	globalLibrary gl = new globalLibrary();
	
	public void showErrors()
	{
		 
	}
	
	public void editJournalPost()
	{
		
	}
	
	public void editJournal()
	{
		
	}
	
	public void editJournalCancel()
	{
		
	}
	
}
