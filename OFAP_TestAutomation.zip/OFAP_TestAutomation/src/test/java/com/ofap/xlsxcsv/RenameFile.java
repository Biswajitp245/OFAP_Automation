package com.ofap.xlsxcsv;

import java.io.File;
import java.util.Date;

import org.testng.annotations.Test;

import com.ofap.base.TestBase;

public class RenameFile extends TestBase
{
	//Rename the File or Folder Name.
	@Test(priority=6)
	public void rename()
	{
		File file = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\" + "outbound.zip");
	    System.out.println(file);
	        
	    Date d = new Date();
		String time = d.toString().replace(":", "_").replace(" ", "_") + ".zip";
		//System.out.println(time);
			
	    File newFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\" + time);
	    System.out.println(newFile);

	    if(file.renameTo(newFile))
	    {
	        System.out.println("File rename success");;
	    }else
	    {
	        System.out.println("File rename failed");
	    }
	}
}
