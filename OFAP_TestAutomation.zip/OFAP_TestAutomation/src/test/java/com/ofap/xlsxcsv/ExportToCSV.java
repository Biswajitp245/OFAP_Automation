package com.ofap.xlsxcsv;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import org.testng.annotations.Test;

import com.ofap.base.globalLibrary;
import com.ofap.utilities.ExcelReader;

/*
 * Steps for Excel to CSV
 * 1. ExportToCSV
 * 2. ZipFolder
 * 3. RenameFile
 * 4. FTPCopyFiles
 * 5. DeleteFolder
 * 6. CreateFolder
 * 
 */
public class ExportToCSV  extends globalLibrary
{
	//Generate CSV File from xlsx
	@Test(priority=2)
	public void exportToCSVHeader() throws IOException
	{
		//Input File as xlsx
		FileInputStream input_document = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx"));
		int rowCnt = excel.getRowCount("XlaTrxH");
		int colCount = excel.getColumnCount("XlaTrxH");
		//Output File as CSV
		PrintWriter pw = new PrintWriter(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\XlaTrxH.csv"));	

		StringBuilder sb = new StringBuilder();
		System.out.println(rowCnt);
		System.out.println(colCount);


		for(int rowitr = 0;rowitr < rowCnt; rowitr++ ) 
		{
			for(int ClmnItr = 0;ClmnItr < colCount;ClmnItr++) 
			{
				sb.append(ExcelReader.getCellData(rowitr, ClmnItr));
				sb.append(",");
			}
			sb.append("\n");
		}
		
		pw.write(sb.toString());
		pw.close();
		System.out.println("Successfully completed");
	}
	
	//Generate CSV File from xlsx
	@Test(priority=3)
		public void exportToCSVLine() throws IOException
		{
			//Input File as xlsx
			FileInputStream input_document = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx"));
			int rowCnt = excel.getRowCount("XlaTrxL");
			int colCount = excel.getColumnCount("XlaTrxL");
			//Output File as CSV
			PrintWriter pw = new PrintWriter(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\XlaTrxL.csv"));	

			StringBuilder sb = new StringBuilder();
			System.out.println(rowCnt);
			System.out.println(colCount);


			for(int rowitr = 0;rowitr < rowCnt; rowitr++ ) 
			{
				for(int ClmnItr = 0;ClmnItr < colCount;ClmnItr++) 
				{
					sb.append(ExcelReader.getCellData(rowitr, ClmnItr));
					sb.append(",");
				}
				sb.append("\n");
			}
			
			pw.write(sb.toString());
			pw.close();
			System.out.println("Successfully completed");
		}
}
