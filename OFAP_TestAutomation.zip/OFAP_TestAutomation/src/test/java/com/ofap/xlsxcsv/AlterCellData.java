package com.ofap.xlsxcsv;

import java.io.FileOutputStream;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ofap.base.TestBase;

public class AlterCellData extends TestBase
{
	
	private static XSSFWorkbook workbook = null; //Excel WorkBook
	private static XSSFCell cell = null;  //Excel cell
	
	public void addColumn()
	{
		excel.addColumn("XlaTrxH", "Status");
	}
	
	//Set Cell Color
		public boolean cellColor()
		{
			excel.setCellData("XlaTrxH", "Status", 2, "Hello");
			FileOutputStream fileOut;
			try {
				CellStyle style = workbook.createCellStyle();
			    style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
				style.setFillPattern(CellStyle.SOLID_FOREGROUND);
				Font font = workbook.createFont();
				font.setColor(IndexedColors.RED.getIndex());
			    style.setFont(font);
			    
			    //excel.addColumn("XlaTrxH", "Status");
			    //excel.setCellData("XlaTrxH", "Status", 2, "Hello");
			    cell.setCellStyle(style);
			}
			catch (Exception e) {			
				e.printStackTrace();
				return false;
			}
			return true;
			
		}
}
