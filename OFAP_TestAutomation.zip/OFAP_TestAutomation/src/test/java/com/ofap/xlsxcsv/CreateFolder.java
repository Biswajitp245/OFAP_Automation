package com.ofap.xlsxcsv;

import java.io.File;

import com.ofap.base.TestBase;

public class CreateFolder extends TestBase
{
	//Create New Folder or Directory
	public void createDirectory()
	{
		File directory = new File( (System.getProperty("user.dir") + "\\src\\test\\resources\\" +  "outbound"));
		if (directory.exists() && directory.isFile())
		{
			System.out.println("The dir with name could not be" + " created as it is a normal file");
		}
		else
		{
			if (!directory.exists())
			{
				directory.mkdir();
			}
			String username = (System.getProperty("user.dir") + "\\src\\test\\resources\\");
			String filename = " path/" + username + ".txt"; //extension if you need one
		}
	}
}
