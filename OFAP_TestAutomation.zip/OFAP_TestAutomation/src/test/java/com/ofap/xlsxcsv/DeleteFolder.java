package com.ofap.xlsxcsv;

import java.io.File;

import com.ofap.base.TestBase;

public class DeleteFolder extends TestBase
{
	//Delete Folder and it's Contains
	public void deleteFolder()
	{
		File dir = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\");

		/*if(dir.isDirectory() == false) 
        {
			System.out.println("Not a directory. Do nothing");
			return;
		} */

		File[] listFiles = dir.listFiles();
		for(File file : listFiles)
		{
			System.out.println("Deleting "+file.getName());
			file.delete();
		} 
		//now directory is empty, so we can delete it
		System.out.println("Deleting Directory. Success = "+dir.delete());
	}
}
