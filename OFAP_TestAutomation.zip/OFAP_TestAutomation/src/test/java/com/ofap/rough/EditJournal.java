package com.ofap.rough;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ofap.base.TestBase;
import com.ofap.utilities.ExcelReader;

public class EditJournal extends TestBase
{
	public static WebDriver driver;
	public static WebElement element;
	public static WebDriverWait wait;
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 10);
		Logger log = Logger.getLogger(EditJournal.class);
		log.info("Browser Launched");
		driver.get("https://fa-elhy-dev3-saasfaprod1.fa.ocs.oraclecloud.com/");
		log.debug("Inside Login Page");
		System.out.println((System.getProperty("user.dir")));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form[@id='Login']")).click();
		driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("gl.initiator");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Oracle123");
		driver.findElement(By.xpath("//button[@id='btnActive']")).click();
				
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='svg-bkgd01 xi8'][@id='pt1:_UIShome::icon']"))).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@title='Journals']")).click();

		driver.findElement(By.xpath("//a[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:_FOTsr1:0:ap1:Journ1:0:sdi1::disAcr']")).click();
		//driver.findElement(By.xpath("//table[@summary='Journals Pending Approval from Others']")).click();
		List<WebElement> htmltable=driver.findElements(By.xpath("//a[contains(@id,'commandLink2')]"));
		
		for(int i=0;i<htmltable.size();i++)

		{
			System.out.println(htmltable.get(i).getText());
			
			//htmltable.get(i).equals("Manual 11019 14-NOV-2019 09:20:26");
			
			if(htmltable.get(i).getText().contentEquals("TITAN M A 48335000001 48337 N")) 
			{
				  
				htmltable.get(i).click(); 
				//break;
	  
			} 
		}
		
		
		
		
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement elem = driver.findElement(By.xpath("//div[@class='x1js']//following::div[@class='xkh x1d4']"));

		 //this line will scroll down to make element visible
		//js.executeScript("window.scrollTo(" + elem.getLocation().x + "," +(elem.getLocation().y- 100) + ");");
		js.executeScript("arguments[0].scrollIntoView(0)", elem);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Account']")).click();
		
		
		//Mouse Hover on Account Link Grid
		
		  Actions action = new Actions(driver);  
		  element = driver.findElement(By.xpath("//span[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS2::content']")); 
		  action.moveToElement(element).build().perform(); 
		  //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]"))).click();

		  driver.findElement(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]")).click();	  
		  List<WebElement> rows=driver.findElements(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]//tbody/tr"));
			
			System.out.println("Number of rows:"+rows.size());
			

			for(int rnum=0;rnum<rows.size();rnum++)
			{
				//System.out.println("Row Wise Details are: "+rows.get(rnum).getText());
				
				List<WebElement> columns=rows.get(rnum).findElements(By.tagName("td"));
				//System.out.println("Number of columns:"+columns.size());
				for(int cnum=1;cnum<columns.size()-1;cnum++)
				{
					System.out.println(columns.get(cnum).getText());
					//excel.setCellData(value, RowNum, ColNum);
				}
	
			}
		
			
			String JGTotalDrFooter = driver.findElement(By.xpath("//span[contains(@id,'EnteredDrFooter')]")).getText();
			String JGTotalCrFooter = driver.findElement(By.xpath("//span[contains(@id,'EnteredCrFooter')]")).getText();
			if(JGTotalDrFooter.equals(JGTotalCrFooter))
			{
				System.out.println("Matching");
				Thread.sleep(3000);
				//driver.findElement(By.xpath("//span[text()='Save']")).click(); 
				System.out.println("Clicking on Save Button");
			}
			else
			{
				driver.findElement(By.xpath("//span[contains(text(),'ancel')]")).click(); 
				System.out.println("Not Matching");
			}
				System.out.println(JGTotalDrFooter +"******" + JGTotalCrFooter);
		
				//driver.findElement(By.xpath("//span[contains(text(),'Post')]")).click(); 
				
				//Your process 63138 has been submitted.	 
		//driver.quit();
	}
	
}
