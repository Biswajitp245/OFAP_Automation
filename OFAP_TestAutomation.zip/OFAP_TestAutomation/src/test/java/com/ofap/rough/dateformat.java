package com.ofap.rough;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.joda.time.LocalDate;

import com.ofap.base.globalLibrary;

public class dateformat extends globalLibrary {

	public static void main(String[] args) throws ParseException {
		
		
		//String FromDate="12/10/20";
		String FromDate=excel.getCellData("exchangeRate", "FromDate", 3);//Read the value from Data base Change String to Column value
        //SimpleDateFormat parser = new SimpleDateFormat("MM/DD/yy");
        SimpleDateFormat formatter = new SimpleDateFormat("m/d/yy");
        String FromDate_Formate=formatter.format(formatter.parse(FromDate));
        System.out.println(FromDate_Formate);
       
        
		/*
		 * String YYYY_MM_DD =null;
			LocalDate today = LocalDate.parse(YYYY_MM_DD);
			DateTimeFormatter MMDDYY_Format = DateTimeFormatter.ofPattern("M/d/yy").format(today);
		 * 
		 * 
		 */

	}

}
