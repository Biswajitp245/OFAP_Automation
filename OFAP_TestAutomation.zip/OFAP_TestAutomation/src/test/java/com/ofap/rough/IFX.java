package com.ofap.rough;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ofap.base.globalLibrary;

public class IFX extends globalLibrary
{
        public static WebDriver driver;
        public static WebElement element;
        public static WebDriverWait wait;
        public static WebElement dropdown;
        public static WebElement htmltable;
        
        static globalLibrary gl = new globalLibrary();
       
        public static void main(String[] args) throws InterruptedException, ParseException, IOException
        {
        	
                int rowCount = excel.getRowCount("exchangeRate");
                System.out.println(rowCount);
                System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
                driver = new ChromeDriver();
                driver.manage().window().maximize();
                driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
                wait = new WebDriverWait(driver, 10);
                Logger log = Logger.getLogger(EditJournal.class);
                log.info("Browser Launched");
                driver.get("https://fa-elhy-dev1-saasfaprod1.fa.ocs.oraclecloud.com/");
                log.debug("Inside Login Page");
                System.out.println((System.getProperty("user.dir")));
                Thread.sleep(2000);
                driver.findElement(By.xpath("//form[@id='Login']")).click();
                driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("ankit.dessore@trafigura.com");
                driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Oracle123");
                driver.findElement(By.xpath("//button[@id='btnActive']")).click();
                Thread.sleep(2000);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='pt1:_UIShome::icon']"))).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath("//div[@title='Setup and Maintenance']")).click();
                driver.findElement(By.xpath("//input[@id='pt1:r1:0:r0:0:r1:0:AP1:s92:it2::content']")).sendKeys("Daily Rates");
                driver.findElement(By.xpath("//div[@id='pt1:r1:0:r0:0:r1:0:AP1:s92:ctb3']")).click();
                driver.findElement(By.xpath("//a[text()='Manage Daily Rates']")).click();
                driver.findElement(By.xpath("//div[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:showDetailItem2::ti']")).click();
                driver.findElement(By.xpath("//select[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value00::content']")).click();

                dropdown = driver.findElement(By.xpath("//select[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value00::content']"));
                Select select = new Select(dropdown);
                String fromCurrencyName = excel.getCellData("currencyMaster", "currency", 25);

                select.selectByVisibleText(fromCurrencyName);
                driver.findElement(By.xpath("//select[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value00::content']")).click();
                Thread.sleep(3000);
                driver.findElement(By.xpath("//label[text()='To Currency']")).click();
                dropdown = driver.findElement(By.xpath("//select[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value10::content']"));
                select = new Select(dropdown);
                String toCurrencyName = excel.getCellData("currencyMaster", "currency", 26);
                select.selectByVisibleText(toCurrencyName);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//select[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value10::content']")).click();

                String fromCurrencyDate = excel.getCellData("exchangeRate", "FromDate", 2);
                String toCurrencyDate = excel.getCellData("exchangeRate", "ToDate", 2);

                System.out.println("From Date   " + fromCurrencyDate);


                System.out.println("To Date   " + toCurrencyDate);

                DataFormatter dataFormatter = new DataFormatter();


                /*Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("M/d/yy");
            fromCurrencyDate = formatter.format(date);
            System.out.println("Date Format with MM/dd/yyyy : "+fromCurrencyDate); */

                /*
                String FromDate="2/16/20";//Read the value from Data base Change String to Column value
                SimpleDateFormat parser = new SimpleDateFormat("MM/DD/yy");
                SimpleDateFormat formatter = new SimpleDateFormat("M/d/yy");
                String FromDate_Formate=formatter.format(parser.parse(FromDate));
                System.out.println(FromDate_Formate);

                String ToDate="4/14/20";//Read the value from Data base ChangeString to Column value
                SimpleDateFormat parser1 = new SimpleDateFormat("MM/DD/yy");
                SimpleDateFormat formatter1 = new SimpleDateFormat("M/d/yy");
                String ToDate_Formate=formatter1.format(parser1.parse(ToDate));
                System.out.println(ToDate_Formate);
				*/
                driver.findElement(By.xpath("//input[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value20::content']")).sendKeys("2/16/20");
                driver.findElement(By.xpath("//input[@id='pt1:r1:0:rt:1:r2:0:dynamicRegion1:0:pt1:AP1:Daily1:0:q1:value21::content']")).sendKeys("2/16/20");
                Thread.sleep(2000);
                driver.findElement(By.xpath("//a[@title='Search:  Rate Type']")).click();

                driver.findElement(By.xpath("//span[text()='Corporate']")).click();
                driver.findElement(By.xpath("//button[text()='Search']")).click();
                
                Thread.sleep(5000);
                
                htmltable= driver.findElement(By.xpath("//table[contains(@summary,'Daily Rates')]"));
        		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
        		  System.out.println("Number of rows:"+rows.size());  
        		  for(int rnum=0;rnum<rows.size();rnum++) 
        		  { 
        			  List<WebElement> columns = rows.get(rnum).findElements(By.xpath("//table[contains(@summary,'Daily Rates')]//following::span[@class='x2s5']")); 
        			  System.out.println("Number of columns:"+columns.size()); 
        			  for(int cnum=0;cnum<columns.size();cnum++) 
        			  { 
        				  int row=0;
        				  String actual = columns.get(cnum).getText();
        				  System.out.println("Actual   " + actual);
        				  //String expect = excel.getCellData("exchangeRate", "FromCurrency", cnum);
        				  String expect = excel.getCellData("exchangeRate", row, cnum);
        				  row++;
        				  //System.out.println("expect    " + expect);
        				  //gl.verifyEquals(expect, actual);
        			  }
        		  }
	}

}
