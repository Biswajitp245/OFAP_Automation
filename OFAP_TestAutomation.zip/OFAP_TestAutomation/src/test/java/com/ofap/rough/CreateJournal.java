package com.ofap.rough;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateJournal 
{
	public static WebDriver driver;
	public static WebElement htmltable;
	
	public static void main(String[] args) throws InterruptedException 
	{
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
		driver = new ChromeDriver();
		//System.setProperty("webdriver.ie.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\IEDriverServer.exe");
		//driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Logger log = Logger.getLogger("devpinoyLogger");
		log.debug("Browser Launched");
		driver.get("https://fa-elhy-dev3-saasfaprod1.fa.ocs.oraclecloud.com/");
		log.debug("Inside Login Page");
		//new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//input[@id='userid']"))));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//form[@id='Login']")).click();
		driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("gl.initiator");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Oracle123");
		driver.findElement(By.xpath("//button[@id='btnActive']")).click();
				
		
		//WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='svg-bkgd01 xi8'][@id='pt1:_UIShome::icon']"))).click();

		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@title='Journals']")).click();
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Journals']"))).click();
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Journals']"))).click();
		
		driver.findElement(By.xpath("//div[@title='Tasks']")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Create Journal']")));
		driver.findElement(By.xpath("//a[text()='Create Journal']")).click();
		
		//Legal Entity select from the Dropdown Table.
		driver.findElement(By.xpath("//span[@class='x1y4'][contains(@id,'showLessLegalEntityCLOV')]")).click(); 
		driver.findElement(By.xpath("//*[text()='Trafigura Pte Ltd']")).click(); //Select any one from the list.
		Thread.sleep(3000);
		
		
		
		/*
		 * htmltable= driver.findElement(By.xpath(
		 * "//table[@class='x1yd'][contains(@id,'showLessLegalEntityCLOV')]"));
		 * List<WebElement> rows1
		 * =htmltable.findElements(By.xpath("//tr[@class='x1yf']"));
		 * System.out.println("Number of rows:"+rows1.size());
		 * 
		 * for(int rnum=0;rnum<rows1.size();rnum++) { List<WebElement>
		 * columns=rows1.get(rnum).findElements(By.tagName("td"));
		 * System.out.println("Number of columns:"+columns.size()); for(int
		 * cnum=0;cnum<columns.size();cnum++) {
		 * System.out.println(columns.get(cnum).getText()); columns.get(1).click();
		 * break; } break; }
		 */
		 
		
		//Category select from the Dropdown Table.
		driver.findElement(By.xpath("//span[@class='x1y4'][contains(@id,'userJeCategoryNameInputSearch1')]")).click(); 
		driver.findElement(By.xpath("//*[text()='Adjust Retirement']")).click(); //Select any one from the list.
		Thread.sleep(1000);
		
		/*
		 * htmltable= driver.findElement(By.xpath(
		 * "//table[@class='x1yd'][contains(@id,'userJeCategoryNameInputSearch1')]"));
		 * List<WebElement>
		 * rows=htmltable.findElements(By.xpath("//tr[@class='x1yd']"));
		 * System.out.println("Number of rows:"+rows.size());
		 * 
		 * for(int rnum=0;rnum<rows.size();rnum++) { List<WebElement>
		 * columns=rows.get(rnum).findElements(By.tagName("td"));
		 * System.out.println("Number of columns:"+columns.size()); for(int
		 * cnum=0;cnum<columns.size();cnum++) {
		 * //System.out.println(columns.get(cnum).getText()); columns.get(10).click();
		 * break; } }
		 */
		 
		
		//From Journal Lines Enter Debit Account

		//((JavascriptExecutor)driver).executeScript("scroll(0,400)");
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		WebElement elem = driver.findElement(By.xpath("//div[@class='x1js']//following::div[@class='xkh x1d4']"));

		 //this line will scroll down to make element visible
		//js.executeScript("window.scrollTo(" + elem.getLocation().x + "," +(elem.getLocation().y- 100) + ");");
		js.executeScript("arguments[0].scrollIntoView(0)", elem);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Account']"));
		
		
		
		//Mouse Hover on Account Link Grid
		
		  //Actions action = new Actions(driver);  
		  //element = driver.findElement(By.xpath("//span[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS2::content']")); 
		  //action.moveToElement(element).build().perform(); 
		  //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]"))).click();

		  //driver.findElement(By.xpath("//table[contains(@id,'accountKff_hover_popTable')]")).click();
		
		  //driver.findElement(By.xpath("//td[@title='Account']")).click();
		
		
		 driver.findElement(By.xpath("//h1[text()='Journal Lines']")).click();
		 driver.findElement(By.xpath("//td[@title='Account']/span/span")).click();
		  Thread.sleep(2000);
		  driver.findElement(By.xpath("//td[@title='Account']/span/span")).sendKeys(Keys.TAB);
		  //driver.findElement(By.xpath("//a[@title='Select: Account']")).sendKeys(Keys.ENTER);
		  driver.findElement(By.xpath("//a[@title='Select: Account']")).click();
		/*
		 * driver.findElement(By.xpath("//table[@class='x1no x1oc']")).click();
		 * WebElement htmltable=
		 * driver.findElement(By.xpath("//table[@class='x1no x1oc']")); List<WebElement>
		 * rows1=htmltable.findElements(By.xpath("tr"));
		 * System.out.println("Number of rows:"+rows1.size());
		 * 
		 * for(int rnum=0;rnum<rows1.size();rnum++) { List<WebElement>
		 * columns=rows1.get(rnum).findElements(By.tagName("td"));
		 * System.out.println("Number of columns:"+columns.size()); for(int
		 * cnum=0;cnum<columns.size();cnum++) { columns.get(1).click();
		 * System.out.println(columns.get(cnum).getText()); } }
		 */
		  //driver.quit();



	}
	
}
