package com.ofap.rough;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test 
{
	public static WebDriver driver;
	
	public void select(String text) {
		List<WebElement> dropdown= driver.findElements(By.xpath("//span[@class='x1y4'][contains(@id,'showLessLegalEntityCLOV')]"));
		
		 
		//Select select = new Select(dropdown);
		//select.selectByVisibleText(text);

		//test.log(LogStatus.INFO, "Selecting from dropdown : " + locator + " text as " + text);

	}

	public static void main(String[] args) throws InterruptedException 
	{
		
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
				driver = new ChromeDriver();
		//System.setProperty("webdriver.ie.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\IEDriverServer.exe");
				//driver = new InternetExplorerDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
				WebDriverWait wait = new WebDriverWait(driver, 10);
				Logger log = Logger.getLogger("devpinoyLogger");
				log.debug("Browser Launched");
				driver.get("https://fa-elhy-dev3-saasfaprod1.fa.ocs.oraclecloud.com/");
				log.debug("Inside Login Page");
				//new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//input[@id='userid']"))));
				Thread.sleep(2000);
				driver.findElement(By.xpath("//form[@id='Login']")).click();
				driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("gl.initiator");
				driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Oracle123");
				driver.findElement(By.xpath("//button[@id='btnActive']")).click();
						
				
				//WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='svg-bkgd01 xi8'][@id='pt1:_UIShome::icon']"))).click();

				Thread.sleep(5000);
				driver.findElement(By.xpath("//div[@title='Journals']")).click();
				//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@title='Journals']"))).click();
				//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@title='Journals']"))).click();
				
				driver.findElement(By.xpath("//div[@title='Tasks']")).click();
				
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Create Journal']")));
				driver.findElement(By.xpath("//a[text()='Create Journal']")).click();
				
				
				driver.findElement(By.xpath("//span[@class='x1y4'][contains(@id,'showLessLegalEntityCLOV')]")).click(); //Legal Entity Dropdown
				driver.findElement(By.xpath("//*[text()='Trafigura Pte Ltd']")).click();
				
				//Test t = new Test();
				//t.select("Trafigura Pte Ltd");
				//driver.findElement(By.xpath("//span[@id='_FOpt1:_FOr1:0:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:showLessLegalEntityCLOV:sis1:SIS_pgl1']")).click();
				Thread.sleep(3000);
		
				driver.findElement(By.xpath("//span[@class='x1y4'][contains(@id,'userJeCategoryNameInputSearch1')]")).click(); //Category Dropdown
				driver.findElement(By.xpath("//*[text()='Adjust Retirement']")).click();
				Thread.sleep(1000);
				//driver.findElement(By.xpath("//h1[contains(text(),'Journal Lines')]")).click();
				//driver.findElement(By.xpath("//input[@id='_FOpt1:_FOr1:0:_FOSritemNode_general_accounting_journals:0:MAnt2:0:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS::content']"));
				  
		/*
		 * JavascriptExecutor executor = (JavascriptExecutor)driver;
		 * 
		 * WebElement scroll = driver.findElement(By.xpath(
		 * "//input[@id='_FOpt1:_FOr1:0:_FOSritemNode_general_accounting_journals:0:MAnt2:0:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS::content']"
		 * ));
		 * 
		 * executor.executeScript("arguments[0].scrollIntoView();", scroll);
		 * 
		 */
				 
				//driver.findElement(By.xpath("//input[@id='_FOpt1:_FOr1:0:_FOSritemNode_general_accounting_journals:0:MAnt2:0:pt1:ap1:jeLineAppTable:_ATp:t3:0:accountCS::content']")).click();
		 
				
				
				  
				

				
				 
				 
				 
				  
				  //driver.findElement(By.linkText("Create Journal")).click();
				  //driver.findElement(By.xpath("//a[text()='Create Journal']")).click();
				  //driver.findElement(By.xpath("//*[@class='_afrImageNotLoadedInTime xi8'][@title='Manage Attachments']")).click();
				  //driver.findElement(By.xpath("//button[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:a1:dc_cb2']")).click();
				  //Thread.sleep(1000);
				  //driver.findElement(By.xpath("//div[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:commandToolbarButton5']//a[@class='xx3']")).click();
				  //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:1:pt1:ap1:commandToolbarButton5']//a[@class='xx3']"))).click();
				  //driver.findElement(By.xpath("//a[@id='pt1:_UIScmil1u']")).click();
				  //driver.findElement(By.xpath("//a[@id='pt1:_UISlg1']")).click();
				  //driver.findElement(By.xpath("//button[@id='Confirm']")).click();
				  Thread.sleep(2000);
				  //driver.quit();

	}

}
