package com.ofap.rough;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ofap.base.globalLibrary;

public class WebTable extends globalLibrary { 
	public static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		// Printing table header of a web table assuming first row as header
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		Logger log = Logger.getLogger("devpinoyLogger");
		log.debug("Browser Launched");
		driver.get("https://fa-elhy-dev3-saasfaprod1.fa.ocs.oraclecloud.com/");
		log.debug("Inside Login Page");	
		driver.findElement(By.xpath("//input[@id='userid']")).sendKeys("gl.initiator");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Oracle123");
		driver.findElement(By.xpath("//button[@id='btnActive']")).click();
				
				
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@class='svg-bkgd01 xi8'][@id='pt1:_UIShome::icon']"))).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@title='Journals']")).click();

		driver.findElement(By.xpath("//a[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:_FOTsr1:0:ap1:Journ1:0:sentForApprovalTab::disAcr']")).click();
		//driver.findElement(By.xpath("//table[@summary='Journals Pending Approval from Others']")).click();
		List<WebElement> htmltable=driver.findElements(By.xpath("//a[contains(@id,'commandLink3')]"));
		
		for(int i=0;i<htmltable.size();i++)

		{
			System.out.println(htmltable.get(i).getText());
			
			//htmltable.get(i).equals("Manual 11019 14-NOV-2019 09:20:26");
			
			if(htmltable.get(i).getText().contentEquals("TITAN M A 50256000001 50257 N")) 
			{
				  
				htmltable.get(i).click(); 
				//break; }
	  
			} 
		}


	}

}
