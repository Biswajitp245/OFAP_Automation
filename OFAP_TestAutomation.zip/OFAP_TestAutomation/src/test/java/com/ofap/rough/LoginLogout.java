package com.ofap.rough;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ofap.base.TestBase;

public class LoginLogout extends TestBase
{
	public static WebDriver driver;
	public static WebElement htmltable;
	
	public static void main(String[] args) throws InterruptedException 
	{
		TestBase tb = new TestBase();
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 10);
		Logger log = Logger.getLogger("devpinoyLogger");
		log.debug("Browser Launched");
		driver.get("https://fa-elhy-dev3-saasfaprod1.fa.ocs.oraclecloud.com/");
		log.debug("Inside Login Page");
		//new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//input[@id='userid']"))));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='ssoBtn']")).click();
		driver.findElement(By.xpath("//input[@name='loginfmt']")).sendKeys("biswajit.pattanaik@trafigura.com");
		driver.findElement(By.xpath("//input[@id='idSIButton9']")).click();
		
				
		
	}

}
