package zip;

import java.io.File;

public class Move 
{

	public static void main(String[] args) 
	{
		
		//Just add the source and destination folder paths.

		//It will move all the files and folder from source folder to destination folder.
		
		File destinationFolder = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\");
	    File sourceFolder = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\");

	    if (!destinationFolder.exists())
	    {
	        destinationFolder.mkdirs();
	    }

	    // Check weather source exists and it is folder.
	    if (sourceFolder.exists() && sourceFolder.isDirectory())
	    {
	        // Get list of the files and iterate over them
	        File[] listOfFiles = sourceFolder.listFiles();

	        if (listOfFiles != null)
	        {
	            for (File child : listOfFiles )
	            {
	                // Move files to destination folder
	                child.renameTo(new File(destinationFolder + "\\" + child.getName()));
	            }

	            // Add if you want to delete the source folder 
	            //sourceFolder.delete();
	        }
	    }
	    else
	    {
	        System.out.println(sourceFolder + "  Folder does not exists");
	    }
	}

}
