package zip;

import java.io.*;
import java.text.ParseException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import com.opencsv.CSVWriter;
import java.util.Iterator;


public class ExcelToCsv 
{

	public static void main(String[] args) throws IOException, ParseException 
	{
		//First we read the Excel file in binary format into FileInputStream
        FileInputStream input_document = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx"));
        // Read workbook into XSSFWorkbook
        XSSFWorkbook my_xls_workbook = new XSSFWorkbook(input_document); 
        // Read worksheet into XSSFSheet
        XSSFSheet my_worksheet = my_xls_workbook.getSheet("XlaTrxH"); 
        
     // To iterate over the rows
        Iterator<Row> rowIterator = my_worksheet.iterator();
        
        //*******************************************************************
        // Retrieving the number of sheets in the Workbook
        System.out.println("Workbook has " + my_xls_workbook.getNumberOfSheets() + " Sheets : ");
        DataFormatter dataFormatter = new DataFormatter();
        /*
           =============================================================
           Iterating over all the sheets in the workbookh
           =============================================================
        */
     // OpenCSV writer object to create CSV file
        FileWriter my_csv=new FileWriter(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\final.csv");
        CSVWriter my_csv_output=new CSVWriter(my_csv);
        // 1. You can obtain a sheetIterator and iterate over it
        Iterator<XSSFSheet> sheetIterator = my_xls_workbook.iterator();
        System.out.println("Retrieving Sheets using Iterator");
        while (sheetIterator.hasNext()) 
        {
            Sheet sheet = sheetIterator.next();
            System.out.println("=> " + sheet.getSheetName());
        

        //*******************************************************************
         
 
        //Loop through rows.
        while(rowIterator.hasNext()) 
        {
                Row row = rowIterator.next(); 
                int i=0;//String array
                //change this depending on the length of your sheet
                String[] csvdata = new String[15]; 

                Iterator<Cell> cellIterator = row.cellIterator();
                        while(cellIterator.hasNext()) 
                        {
                                Cell cell = cellIterator.next(); //Fetch CELL
                                
                                csvdata[i] = dataFormatter.formatCellValue(cell); //We can store any type of data (Date, Numeric, String, Char)
                                switch(cell.getCellType())
                                { //Identify CELL type
                                case Cell.CELL_TYPE_STRING:
                                        csvdata[i]= cell.getStringCellValue();                                              
                                        break;
                                }
                                i=i+1;
                        }
                    my_csv_output.writeNext(csvdata);
        	}
        }
        my_csv_output.close(); //close the CSV file
        //we created our file..!!
        input_document.close(); //close xls

	}

}
