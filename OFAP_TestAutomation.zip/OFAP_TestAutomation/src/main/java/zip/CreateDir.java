package zip;

import java.io.File;


public class CreateDir 
{

	public static void main(String[] args) 
	{
		File directory = new File( (System.getProperty("user.dir") + "\\src\\test\\resources\\" +  "outbound"));
	    if (directory.exists() && directory.isFile())
	    {
	        System.out.println("The dir with name could not be" + " created as it is a normal file");
	    }
	    else
	    {
	        if (!directory.exists())
			{
			    directory.mkdir();
			    System.out.println("Directory Created");
			}
			String username = (System.getProperty("user.dir") + "\\src\\test\\resources\\");
			String filename = " path/" + username + ".txt"; //extension if you need one
	    }

	}

}
