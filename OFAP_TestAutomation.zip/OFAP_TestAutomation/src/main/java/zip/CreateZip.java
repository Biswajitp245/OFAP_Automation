package zip;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


//Currently not required this code.

public class CreateZip {

	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		StringBuilder sb = new StringBuilder();
		sb.append("Test String");

		File f = new File("C:\\Users\\Biswajit.Pattanaik\\OFAP_TestAutomation\\src\\test\\resources\\excel\\fileZip.zip");
		ZipOutputStream out = new ZipOutputStream(new FileOutputStream(f));
		ZipEntry e = new ZipEntry("XlaTrxH.csv");
		out.putNextEntry(e);

		byte[] data = sb.toString().getBytes();
		out.write(data, 0, data.length);
		out.closeEntry();

		out.close();

	}

}
