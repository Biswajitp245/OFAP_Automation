package zip;

import java.io.File;
import java.io.IOException;
import java.util.Date;


public class Rename 
{
	public static void main(String[] args) throws IOException 
	{
		//Rename the File or Folder Name.
		
		File file = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\" + "outbound.zip");
        System.out.println(file);
        
        Date d = new Date();
		String time = d.toString().replace(":", "_").replace(" ", "_") + ".zip";
		//System.out.println(time);
		
        File newFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\outbound\\" + time);
        System.out.println(newFile);

        if(file.renameTo(newFile)){
            System.out.println("File rename success");;
        }else{
            System.out.println("File rename failed");
        }
        
        

	}

}
