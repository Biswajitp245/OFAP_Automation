package zip;

import java.io.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.Iterator;
import com.opencsv.CSVWriter;

public class x2c 
{

	public static void main(String[] args) throws IOException 
	{
		//First we read the Excel file in binary format into FileInputStream
        FileInputStream input_document = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\outputdata.xlsx"));
        // Read workbook into HSSFWorkbook
        XSSFWorkbook my_xls_workbook = new XSSFWorkbook(input_document); 
        // Read worksheet into HSSFSheet
        XSSFSheet my_worksheet = my_xls_workbook.getSheetAt(0);
        //XSSFSheet my_worksheet = my_xls_workbook.getSheet("XlaTrxL"); 
        System.out.println("Workbook has " + my_xls_workbook.getNumberOfSheets() + " Sheets : ");
        DataFormatter dataFormatter = new DataFormatter();
        // To iterate over the rows
        Iterator<Row> rowIterator = my_worksheet.iterator();
        // OpenCSV writer object to create CSV file
        FileWriter my_csv=new FileWriter(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\final.csv");
        CSVWriter my_csv_output=new CSVWriter(my_csv); 
        
        System.out.println("Retrieving Sheets using Iterator");
        //Loop through rows.
        while(rowIterator.hasNext()) 
        {
           Row row = rowIterator.next(); 
           //System.out.println("=> " + my_worksheet.getSheetName());
           int i=0;//String array
           //change this depending on the length of your sheet
                String[] csvdata = new String[500];
                Iterator<Cell> cellIterator = row.cellIterator();
                        while(cellIterator.hasNext()) 
                        {
                                Cell cell = cellIterator.next(); //Fetch CELL
                                csvdata[i] = dataFormatter.formatCellValue(cell); //We can store any type of data (Date, Numeric, String, Char)
                                switch(cell.getCellType()) 
                                { 
                                case Cell.CELL_TYPE_STRING:
                                        csvdata[i]= cell.getStringCellValue();                                              
                                        break;
                                }
                                i=i+1;
                        }
        my_csv_output.writeNext(csvdata);
        }
        my_csv_output.close(); //close the CSV file
        //we created our file..!!
        input_document.close(); //close xls

	}

}
