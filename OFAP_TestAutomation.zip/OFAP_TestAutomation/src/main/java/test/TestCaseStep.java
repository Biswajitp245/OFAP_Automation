package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class TestCaseStep 
{
	//TITAN Test Case Steps
	//Step 1: Open Chrome Browser
	//Step 2: Navigate to the OFAP Site
	//Step 3: Clicking on Journal Icon
	//Step 4: Open Review Journal Page
	//Get the total number of rows using absolute XPath
	//Get the total number of columns using relative XPath
	//Print row and column count to console
	//Get all row values by tag name �tr�
	//Get the column header values in a list by tag name �th�
	//Loop through the header values and print them to console
	//Loop through the table contents (all columns for each row) and get its text
	//Print the values to console
	//Print the table contents to console using fixed row and column numbers
	

		// Declaring variables
			private WebDriver driver;
			private String baseUrl;
	
			@Test
			public void testPageTitle() throws Exception {
				// Open baseUrl in Firefox browser window
				driver.get(baseUrl);
				// Locate 'Books & Authors' table using id
				WebElement BooksTable = driver.findElement(By.id("BooksAuthorsTable"));
				//Get all web elements by tag name 'tr'
				List<WebElement> rowVals = BooksTable.findElements(By.tagName("tr"));
				
				//Get number of rows and columns
				//using absoulute xpath
				int rowNum = driver.findElements(By.xpath("/html/body/form/div[5]/div/div/table/tbody/tr")).size();
				//using relative xpath
				int colNum = driver.findElements(By.xpath("//table[@id='BooksAuthorsTable']/tbody/tr[1]/th")).size();
				System.out.println("Total number of rows = " + rowNum);
				System.out.println("Total number of columns = " + colNum);
				
				//Get column header values from first row
				List<WebElement> colHeader = rowVals.get(0).findElements(By.tagName("th"));
				//Loop through the header values and print them to console
				System.out.println("Header values:");
				for(int i=0; i<colHeader.size(); i++){
					System.out.println(colHeader.get(i).getText());
				}
				System.out.println("---------------");
				//Loop through the remaining rows
				for(int i=1; i<rowNum; i++){
					//Get each row's column values by tag name
					List<WebElement> colVals = rowVals.get(i).findElements(By.tagName("td"));
					//Loop through each column
					for(int j=0; j<colNum; j++){
						//Print the coulumn values to console
						System.out.println(colVals.get(j).getText());
					}
					//Just a separator for each row
					System.out.println("---------------");
				}			
				
				//Printing table contents to console for fixed row and column numbers
				for(int i=2; i<=6; i++){
					for(int j=1; j<=4; j++){
						System.out.print(driver.findElement(By.
								xpath("//table[@id='BooksAuthorsTable']/tbody/tr[" + i +"]/td[" + j + "]")).getText() + "\t");
					}
					System.out.println("");
				}
				
			} //End of @Test

	
}
