package test;

public class skip1 {

}
