package test;

public class SplitString 
{

	public static void main(String[] args) 
	{
		
		String strMain = "Steve Madden Singh: Person Management";
		  
		  String[] arrSplit = strMain.split(": "); 
		  for (int i=0; i < arrSplit.length -1;i++) 
		  System.out.println(arrSplit[0]); 

	}

}
