package test;

public class Position 
{

	public static void main(String[] args) 
	{
		
		//Verify First Name as: Biswajit
		//Verify First Name as: Pattanaik
				
			String lableName = "Biswajit Pattanaik Das: Person Management";
			//String s = str.substring(0,str.indexOf(":"));
			
			//System.out.println(s);
			
			//int position = str.indexOf(":");
			//str.substring(0,int getposition(":",str));
			//System.out.println(position);
			//System.out.println(str.substring(0,str.indexOf(":")));
			String []s1 = lableName.split(":");
			if (s1 != null && s1.length >0)
			{
				String []s2 = s1[0].split(" ");
				if(s2 != null)
				{
					String fn = "", mn="", ln="";
					if (s2.length==1)
					{
						fn = s2[0];
					}else if (s2.length==2)
					{
						fn = s2[0];
						mn = s2[1];
					}else if (s2.length==3)
					{
						fn = s2[0];
						mn = s2[1];
						ln = s2[2];
					}
					System.out.println("First Name: " + fn + "\n Middle Name: " + mn + "\n Last Name: " + ln);
				}
			}
			
	}

}
