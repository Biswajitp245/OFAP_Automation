package test;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.joda.time.LocalDate;

public class dateformat  {

	public static void main(String[] args) throws ParseException {
		
		
		
		String FromDate="02/16/20";//Read the value from Data base Change String to Column value
        SimpleDateFormat parser = new SimpleDateFormat("MM/DD/yy");
        SimpleDateFormat formatter = new SimpleDateFormat("M/d/yy");
        String FromDate_Formate=formatter.format(parser.parse(FromDate));
        System.out.println(FromDate_Formate);
        
		/*
		 * String YYYY_MM_DD =null;
			LocalDate today = LocalDate.parse(YYYY_MM_DD);
			DateTimeFormatter MMDDYY_Format = DateTimeFormatter.ofPattern("M/d/yy").format(today);
		 * 
1. Set of Files from Scource 
2. Integration OIC-DBCS-AHCS-GL
3. Check
4. Oracle GL- All the files are processed - Specify Fields
5. Reconcile the Excel with Source and Tragate
6. Mark as If it is matching OK Green or Fail in Red
7. 


Automa approch
Regression Approch
Automation Plan
		 * 
		 */

	}

}
