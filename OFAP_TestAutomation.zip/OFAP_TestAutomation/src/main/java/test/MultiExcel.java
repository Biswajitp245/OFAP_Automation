package test;

public class MultiExcel 
{
	// Sub GetSheets()
	 //'Update ExcelJunction.com
	// Path = "C:\Users\Biswajit.Pattanaik\Desktop\Output\"
	// Filename = Dir(Path & "*.xlsx")
	// Do While Filename <> ""
	// Workbooks.Open Filename:=Path & Filename, ReadOnly:=True
	// For Each Sheet In ActiveWorkbook.Sheets()
	// Sheet.Copy After:=ThisWorkbook.Sheets(1)
	// Next Sheet
	// Workbooks(Filename).Close
	// Filename = Dir()
	// Loop
	// End Sub

}
