package test;

public class Xpath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i=0; i<=10; i++)
		{
			String x ="//button[@id='pt1:_FOr1:1:_FOSritemNode_general_accounting_journals:0:MAnt2:2:AP1:AT1:_ATp:table1:";
			String y = ":d2::ok']";
			String z = x + (i+0) + y;
		  System.out.println(z);
		}
	}

}
