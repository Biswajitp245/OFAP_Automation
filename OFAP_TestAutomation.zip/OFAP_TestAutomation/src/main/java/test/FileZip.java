package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
//No more required this code.
public class FileZip {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File[] files = {new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\XlaTrxH.csv"), 
				new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\XlaTrxL.csv"),
				new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\Metadata_TITAN_NR.txt")};

		//System.out.println(files[0]);
		//System.out.println(files[1]);
		//System.out.println(files[2]);
		File zipFileName = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\Zippedfile.zip");
		//File zipFileName = new File(System.setProperties(("user.dir") + "\\src\\test\\resources\\excel\\Zippedfile.zip"));
		createZipFile(files, zipFileName);                              
	}

	public static void createZipFile(File[] selected,File  zipFileName)
	{
		try
		{
			byte[] buffer = new byte[1024];
			FileOutputStream output = new FileOutputStream(zipFileName); 
			ZipOutputStream zos = new ZipOutputStream(output);

			for (int i = 0; i < selected.length; i++)
			{ 

				File in = new File(selected[i].toString()); 
				FileInputStream fis = new FileInputStream(in);

				zos.putNextEntry(new ZipEntry(in.getName())); 
				int len; 
				while ((len = fis.read(buffer)) > 0) 

				{ 
					zos.write(buffer, 0, len); 
				} 
				zos.closeEntry(); 
				fis.close(); 
			}
			output.close(); 
		}  
		catch (IllegalArgumentException iae) 
		{  
			iae.printStackTrace(); 
		} 
		catch (FileNotFoundException fnfe) 
		{ 
			fnfe.printStackTrace(); 
		} 
		catch (IOException ioe) 
		{ 
			ioe.printStackTrace(); 
		} 


	}

}
